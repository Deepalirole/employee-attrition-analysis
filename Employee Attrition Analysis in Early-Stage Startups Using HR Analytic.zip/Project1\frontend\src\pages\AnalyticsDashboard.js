import React, { useState, useEffect } from 'react';
import { analyticsAPI } from '../services/api';
import { LoadingSpinner } from '../components/LoadingSpinner';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area,
  ResponsiveContainer
} from 'recharts';

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#F97316'];

const AnalyticsDashboard = () => {
  const [analytics, setAnalytics] = useState(null);
  const [trends, setTrends] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    fetchAnalyticsData();
  }, []);

  const fetchAnalyticsData = async () => {
    try {
      setLoading(true);
      const [analyticsResponse, trendsResponse] = await Promise.all([
        analyticsAPI.getDashboard(),
        analyticsAPI.getTrends()
      ]);
      
      setAnalytics(analyticsResponse.data);
      setTrends(trendsResponse.data);
    } catch (err) {
      console.error('Failed to fetch analytics data:', err);
      setError('Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  const prepareDepartmentData = () => {
    if (!analytics?.departmentWiseAttrition) return [];
    
    return Object.entries(analytics.departmentWiseAttrition).map(([dept, count]) => ({
      name: dept,
      attrition: count
    }));
  };

  const prepareGenderData = () => {
    if (!analytics?.genderDistribution) return [];
    
    return Object.entries(analytics.genderDistribution).map(([gender, count]) => ({
      name: gender,
      value: count
    }));
  };

  const prepareSalaryData = () => {
    if (!analytics?.salaryWiseAttrition) return [];
    
    return Object.entries(analytics.salaryWiseAttrition).map(([range, percentage]) => ({
      range,
      attritionRate: percentage
    }));
  };

  const prepareExperienceData = () => {
    if (!analytics?.experienceAnalysis) return [];
    
    return Object.entries(analytics.experienceAnalysis).map(([range, count]) => ({
      range,
      employees: count
    }));
  };

  const prepareMonthlyData = () => {
    if (!trends?.monthlyTrends) return [];
    
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    return months.map(month => ({
      month,
      attrition: trends.monthlyTrends[month] || 0
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-600 mb-4">{error}</div>
        <button onClick={fetchAnalyticsData} className="btn btn-primary">
          Retry
        </button>
      </div>
    );
  }

  const departmentData = prepareDepartmentData();
  const genderData = prepareGenderData();
  const salaryData = prepareSalaryData();
  const experienceData = prepareExperienceData();
  const monthlyData = prepareMonthlyData();

  return (
    <div className="space-y-6">
      <div className="border-b border-gray-200 pb-5">
        <h1 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h1>
        <p className="mt-2 text-gray-600">Comprehensive HR analytics and insights</p>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {['overview', 'attrition', 'demographics', 'trends'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-2 px-1 border-b-2 font-medium text-sm capitalize ${
                activeTab === tab
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              {tab}
            </button>
          ))}
        </nav>
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="stat-card">
              <div className="stat-label">Total Employees</div>
              <div className="stat-value">{analytics?.totalEmployees || 0}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Attrition Rate</div>
              <div className="stat-value">{analytics?.attritionPercentage?.toFixed(1) || 0}%</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">Average Salary</div>
              <div className="stat-value">${analytics?.averageSalary?.toFixed(0) || 0}</div>
            </div>
            <div className="stat-card">
              <div className="stat-label">High Risk Employees</div>
              <div className="stat-value">{analytics?.highRiskEmployees || 0}</div>
            </div>
          </div>

          {/* Department-wise Attrition */}
          <div className="card">
            <div className="card-header">
              <h3 className="text-lg font-medium text-gray-900">Department-wise Attrition</h3>
            </div>
            <div className="card-body">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={departmentData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="attrition" fill="#EF4444" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Attrition Tab */}
      {activeTab === 'attrition' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Salary-wise Attrition */}
            <div className="card">
              <div className="card-header">
                <h3 className="text-lg font-medium text-gray-900">Attrition by Salary Range</h3>
              </div>
              <div className="card-body">
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={salaryData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="range" />
                    <YAxis />
                    <Tooltip formatter={(value) => `${value}%`} />
                    <Legend />
                    <Bar dataKey="attritionRate" fill="#F59E0B" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Experience Analysis */}
            <div className="card">
              <div className="card-header">
                <h3 className="text-lg font-medium text-gray-900">Employee Experience Distribution</h3>
              </div>
              <div className="card-body">
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={experienceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="range" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area type="monotone" dataKey="employees" stroke="#3B82F6" fill="#3B82F6" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Demographics Tab */}
      {activeTab === 'demographics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Gender Distribution */}
            <div className="card">
              <div className="card-header">
                <h3 className="text-lg font-medium text-gray-900">Gender Distribution</h3>
              </div>
              <div className="card-body">
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={genderData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: ${value}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {genderData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="card">
              <div className="card-header">
                <h3 className="text-lg font-medium text-gray-900">Performance Metrics</h3>
              </div>
              <div className="card-body">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-500">Average Performance Rating</span>
                    <span className="text-lg font-bold text-gray-900">
                      {analytics?.averagePerformanceRating?.toFixed(1) || 0}/5
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-500">Average Work-Life Balance</span>
                    <span className="text-lg font-bold text-gray-900">
                      {analytics?.averageWorkLifeBalance?.toFixed(1) || 0}/5
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-500">Overtime Employees</span>
                    <span className="text-lg font-bold text-gray-900">
                      {analytics?.overtimeEmployees || 0}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-gray-500">High Risk Employees</span>
                    <span className="text-lg font-bold text-gray-900">
                      {analytics?.highRiskEmployees || 0}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Trends Tab */}
      {activeTab === 'trends' && (
        <div className="space-y-6">
          <div className="card">
            <div className="card-header">
              <h3 className="text-lg font-medium text-gray-900">Monthly Attrition Trends</h3>
            </div>
            <div className="card-body">
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="attrition" stroke="#EF4444" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AnalyticsDashboard;
