package com.hr.analytics.service;

import com.hr.analytics.dto.DepartmentDTO;
import com.hr.analytics.entity.Department;
import com.hr.analytics.repository.DepartmentRepository;
import com.hr.analytics.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service class for Department management
 * Contains business logic for department operations
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final EmployeeRepository employeeRepository;

    /**
     * Create a new department
     */
    public DepartmentDTO createDepartment(DepartmentDTO departmentDTO) {
        log.info("Creating new department: {}", departmentDTO.getName());
        
        if (departmentRepository.existsByName(departmentDTO.getName())) {
            throw new RuntimeException("Department already exists");
        }

        Department department = convertToEntity(departmentDTO);
        Department savedDepartment = departmentRepository.save(department);
        
        log.info("Department created successfully with ID: {}", savedDepartment.getId());
        return convertToDTO(savedDepartment);
    }

    /**
     * Update an existing department
     */
    public DepartmentDTO updateDepartment(Long id, DepartmentDTO departmentDTO) {
        log.info("Updating department with ID: {}", id);
        
        Department existingDepartment = departmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Department not found with ID: " + id));

        // Check if name is being changed and if it already exists
        if (!existingDepartment.getName().equals(departmentDTO.getName()) &&
            departmentRepository.existsByName(departmentDTO.getName())) {
            throw new RuntimeException("Department name already exists");
        }

        // Update department fields
        existingDepartment.setName(departmentDTO.getName());
        existingDepartment.setDescription(departmentDTO.getDescription());
        existingDepartment.setHeadOfDepartment(departmentDTO.getHeadOfDepartment());
        existingDepartment.setIsActive(departmentDTO.getIsActive());

        Department updatedDepartment = departmentRepository.save(existingDepartment);
        
        log.info("Department updated successfully with ID: {}", updatedDepartment.getId());
        return convertToDTO(updatedDepartment);
    }

    /**
     * Get department by ID
     */
    public DepartmentDTO getDepartmentById(Long id) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Department not found with ID: " + id));
        return convertToDTO(department);
    }

    /**
     * Get department by name
     */
    public DepartmentDTO getDepartmentByName(String name) {
        Department department = departmentRepository.findByName(name)
                .orElseThrow(() -> new RuntimeException("Department not found with name: " + name));
        return convertToDTO(department);
    }

    /**
     * Get all departments
     */
    public List<DepartmentDTO> getAllDepartments() {
        List<Department> departments = departmentRepository.findAll();
        return departments.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get all active departments
     */
    public List<DepartmentDTO> getActiveDepartments() {
        List<Department> departments = departmentRepository.findByIsActive(true);
        return departments.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Delete department by ID
     */
    public void deleteDepartment(Long id) {
        log.info("Deleting department with ID: {}", id);
        
        if (!departmentRepository.existsById(id)) {
            throw new RuntimeException("Department not found with ID: " + id);
        }

        // Check if there are employees in this department
        Department department = departmentRepository.findById(id).get();
        Long employeeCount = employeeRepository.findByDepartment(department.getName()).stream().count();
        
        if (employeeCount > 0) {
            throw new RuntimeException("Cannot delete department with " + employeeCount + " employees");
        }
        
        departmentRepository.deleteById(id);
        log.info("Department deleted successfully with ID: {}", id);
    }

    /**
     * Update department employee count
     */
    public void updateDepartmentEmployeeCount(String departmentName) {
        Optional<Department> departmentOpt = departmentRepository.findByName(departmentName);
        
        if (departmentOpt.isPresent()) {
            Department department = departmentOpt.get();
            Long employeeCount = employeeRepository.findByDepartment(departmentName).stream().count();
            department.setEmployeeCount(employeeCount.intValue());
            departmentRepository.save(department);
            
            log.info("Updated employee count for department {}: {}", departmentName, employeeCount);
        }
    }

    /**
     * Get department statistics
     */
    public DepartmentDTO getDepartmentStatistics(String departmentName) {
        log.info("Getting statistics for department: {}", departmentName);
        
        DepartmentDTO departmentDTO = getDepartmentByName(departmentName);
        
        // Calculate additional statistics
        Long totalEmployees = employeeRepository.findByDepartment(departmentName).stream().count();
        Long attritionCount = employeeRepository.findByDepartmentAndAttritionStatus(departmentName, true).stream().count();
        
        departmentDTO.setEmployeeCount(totalEmployees.intValue());
        
        // Add additional statistics if needed
        // This could be extended to include more metrics
        
        return departmentDTO;
    }

    /**
     * Convert Department entity to DepartmentDTO
     */
    private DepartmentDTO convertToDTO(Department department) {
        DepartmentDTO dto = new DepartmentDTO();
        dto.setId(department.getId());
        dto.setName(department.getName());
        dto.setDescription(department.getDescription());
        dto.setHeadOfDepartment(department.getHeadOfDepartment());
        dto.setEmployeeCount(department.getEmployeeCount());
        dto.setIsActive(department.getIsActive());
        return dto;
    }

    /**
     * Convert DepartmentDTO to Department entity
     */
    private Department convertToEntity(DepartmentDTO dto) {
        Department department = new Department();
        department.setName(dto.getName());
        department.setDescription(dto.getDescription());
        department.setHeadOfDepartment(dto.getHeadOfDepartment());
        department.setEmployeeCount(dto.getEmployeeCount());
        department.setIsActive(dto.getIsActive());
        return department;
    }

    /**
     * Initialize default departments
     */
    public void initializeDefaultDepartments() {
        log.info("Initializing default departments");
        
        String[] defaultDepartments = {
            "Engineering", "Sales", "Marketing", "Human Resources", 
            "Finance", "Operations", "Customer Support", "IT"
        };
        
        for (String deptName : defaultDepartments) {
            if (!departmentRepository.existsByName(deptName)) {
                Department department = new Department();
                department.setName(deptName);
                department.setDescription("Default " + deptName + " department");
                department.setIsActive(true);
                department.setEmployeeCount(0);
                departmentRepository.save(department);
                
                log.info("Created default department: {}", deptName);
            }
        }
    }
}
