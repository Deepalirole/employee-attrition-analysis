package com.hr.analytics.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.util.Map;

/**
 * Analytics DTO for dashboard statistics
 * Contains various metrics for HR analytics
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AnalyticsDTO {

    private Long totalEmployees;
    private Long attritionCount;
    private Double attritionPercentage;
    private Map<String, Long> departmentWiseAttrition;
    private Map<String, Long> genderDistribution;
    private Map<String, Double> salaryWiseAttrition;
    private Map<String, Long> experienceAnalysis;
    private Map<String, Long> monthlyTrends;
    private Double averageSalary;
    private Double averageWorkLifeBalance;
    private Double averagePerformanceRating;
    private Long overtimeEmployees;
    private Long highRiskEmployees;
}
