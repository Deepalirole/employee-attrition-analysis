package com.hr.analytics.repository;

import com.hr.analytics.entity.AttritionRecord;
import com.hr.analytics.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * Repository interface for AttritionRecord entity
 * Provides database operations for attrition history tracking
 */
@Repository
public interface AttritionRecordRepository extends JpaRepository<AttritionRecord, Long> {

    List<AttritionRecord> findByEmployee(Employee employee);

    List<AttritionRecord> findByAttritionDateBetween(LocalDate startDate, LocalDate endDate);

    @Query("SELECT ar FROM AttritionRecord ar WHERE ar.employee.department = :department")
    List<AttritionRecord> findByDepartment(@Param("department") String department);

    @Query("SELECT ar FROM AttritionRecord ar WHERE YEAR(ar.attritionDate) = :year")
    List<AttritionRecord> findByYear(@Param("year") int year);

    @Query("SELECT ar FROM AttritionRecord ar WHERE YEAR(ar.attritionDate) = :year AND MONTH(ar.attritionDate) = :month")
    List<AttritionRecord> findByYearAndMonth(@Param("year") int year, @Param("month") int month);

    @Query("SELECT COUNT(ar) FROM AttritionRecord ar WHERE ar.attritionDate BETWEEN :startDate AND :endDate")
    Long countByDateRange(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    @Query("SELECT MONTH(ar.attritionDate), COUNT(ar) FROM AttritionRecord ar WHERE YEAR(ar.attritionDate) = :year GROUP BY MONTH(ar.attritionDate)")
    List<Object[]> getMonthlyAttritionByYear(@Param("year") int year);

    @Query("SELECT ar.attritionReason, COUNT(ar) FROM AttritionRecord ar GROUP BY ar.attritionReason")
    List<Object[]> getAttritionReasons();

    @Query("SELECT ar FROM AttritionRecord ar WHERE ar.replacementHired = false")
    List<AttritionRecord> findUnreplacedAttrition();

    @Query("SELECT AVG(DATEDIFF(ar.replacementDate, ar.attritionDate)) FROM AttritionRecord ar WHERE ar.replacementHired = true AND ar.replacementDate IS NOT NULL")
    Double getAverageReplacementTime();
}
