package com.hr.analytics.controller;

import com.hr.analytics.dto.EmployeeDTO;
import com.hr.analytics.service.EmployeeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST Controller for Employee management operations
 * Handles CRUD operations and employee-related queries
 */
@RestController
@RequestMapping("/employees")
@RequiredArgsConstructor
@Slf4j
public class EmployeeController {

    private final EmployeeService employeeService;

    /**
     * Create a new employee
     */
    @PostMapping
    public ResponseEntity<EmployeeDTO> createEmployee(@Valid @RequestBody EmployeeDTO employeeDTO) {
        log.info("Creating new employee: {}", employeeDTO.getEmployeeId());
        
        try {
            EmployeeDTO createdEmployee = employeeService.createEmployee(employeeDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdEmployee);
        } catch (Exception e) {
            log.error("Failed to create employee", e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Update an existing employee
     */
    @PutMapping("/{id}")
    public ResponseEntity<EmployeeDTO> updateEmployee(@PathVariable Long id, 
                                                      @Valid @RequestBody EmployeeDTO employeeDTO) {
        log.info("Updating employee with ID: {}", id);
        
        try {
            EmployeeDTO updatedEmployee = employeeService.updateEmployee(id, employeeDTO);
            return ResponseEntity.ok(updatedEmployee);
        } catch (Exception e) {
            log.error("Failed to update employee with ID: {}", id, e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Get employee by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<EmployeeDTO> getEmployeeById(@PathVariable Long id) {
        log.info("Fetching employee with ID: {}", id);
        
        try {
            EmployeeDTO employee = employeeService.getEmployeeById(id);
            return ResponseEntity.ok(employee);
        } catch (Exception e) {
            log.error("Failed to fetch employee with ID: {}", id, e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    /**
     * Get employee by employee ID
     */
    @GetMapping("/employee-id/{employeeId}")
    public ResponseEntity<EmployeeDTO> getEmployeeByEmployeeId(@PathVariable String employeeId) {
        log.info("Fetching employee with employee ID: {}", employeeId);
        
        try {
            EmployeeDTO employee = employeeService.getEmployeeByEmployeeId(employeeId);
            return ResponseEntity.ok(employee);
        } catch (Exception e) {
            log.error("Failed to fetch employee with employee ID: {}", employeeId, e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    /**
     * Get all employees
     */
    @GetMapping
    public ResponseEntity<List<EmployeeDTO>> getAllEmployees() {
        log.info("Fetching all employees");
        
        try {
            List<EmployeeDTO> employees = employeeService.getAllEmployees();
            return ResponseEntity.ok(employees);
        } catch (Exception e) {
            log.error("Failed to fetch all employees", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Delete employee by ID
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteEmployee(@PathVariable Long id) {
        log.info("Deleting employee with ID: {}", id);
        
        try {
            employeeService.deleteEmployee(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "Employee deleted successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to delete employee with ID: {}", id, e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Search employees by name
     */
    @GetMapping("/search")
    public ResponseEntity<List<EmployeeDTO>> searchEmployeesByName(@RequestParam String name) {
        log.info("Searching employees by name: {}", name);
        
        try {
            List<EmployeeDTO> employees = employeeService.searchEmployeesByName(name);
            return ResponseEntity.ok(employees);
        } catch (Exception e) {
            log.error("Failed to search employees by name: {}", name, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get employees by department
     */
    @GetMapping("/department/{department}")
    public ResponseEntity<List<EmployeeDTO>> getEmployeesByDepartment(@PathVariable String department) {
        log.info("Fetching employees by department: {}", department);
        
        try {
            List<EmployeeDTO> employees = employeeService.getEmployeesByDepartment(department);
            return ResponseEntity.ok(employees);
        } catch (Exception e) {
            log.error("Failed to fetch employees by department: {}", department, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get employees by attrition status
     */
    @GetMapping("/attrition/{attritionStatus}")
    public ResponseEntity<List<EmployeeDTO>> getEmployeesByAttritionStatus(@PathVariable Boolean attritionStatus) {
        log.info("Fetching employees by attrition status: {}", attritionStatus);
        
        try {
            List<EmployeeDTO> employees = employeeService.getEmployeesByAttritionStatus(attritionStatus);
            return ResponseEntity.ok(employees);
        } catch (Exception e) {
            log.error("Failed to fetch employees by attrition status: {}", attritionStatus, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get employees by age range
     */
    @GetMapping("/age-range")
    public ResponseEntity<List<EmployeeDTO>> getEmployeesByAgeRange(@RequestParam Integer minAge, 
                                                                   @RequestParam Integer maxAge) {
        log.info("Fetching employees by age range: {} to {}", minAge, maxAge);
        
        try {
            List<EmployeeDTO> employees = employeeService.getEmployeesByAgeRange(minAge, maxAge);
            return ResponseEntity.ok(employees);
        } catch (Exception e) {
            log.error("Failed to fetch employees by age range: {} to {}", minAge, maxAge, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get employees by salary range
     */
    @GetMapping("/salary-range")
    public ResponseEntity<List<EmployeeDTO>> getEmployeesBySalaryRange(@RequestParam Double minSalary, 
                                                                       @RequestParam Double maxSalary) {
        log.info("Fetching employees by salary range: {} to {}", minSalary, maxSalary);
        
        try {
            List<EmployeeDTO> employees = employeeService.getEmployeesBySalaryRange(minSalary, maxSalary);
            return ResponseEntity.ok(employees);
        } catch (Exception e) {
            log.error("Failed to fetch employees by salary range: {} to {}", minSalary, maxSalary, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get employees by years at company range
     */
    @GetMapping("/experience-range")
    public ResponseEntity<List<EmployeeDTO>> getEmployeesByYearsAtCompanyRange(@RequestParam Integer minYears, 
                                                                                @RequestParam Integer maxYears) {
        log.info("Fetching employees by years at company range: {} to {}", minYears, maxYears);
        
        try {
            List<EmployeeDTO> employees = employeeService.getEmployeesByYearsAtCompanyRange(minYears, maxYears);
            return ResponseEntity.ok(employees);
        } catch (Exception e) {
            log.error("Failed to fetch employees by years at company range: {} to {}", minYears, maxYears, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get employee statistics
     */
    @GetMapping("/statistics")
    public ResponseEntity<?> getEmployeeStatistics() {
        log.info("Fetching employee statistics");
        
        try {
            Map<String, Object> statistics = new HashMap<>();
            
            // Basic counts
            List<EmployeeDTO> allEmployees = employeeService.getAllEmployees();
            List<EmployeeDTO> activeEmployees = employeeService.getEmployeesByAttritionStatus(false);
            List<EmployeeDTO> attritedEmployees = employeeService.getEmployeesByAttritionStatus(true);
            
            statistics.put("totalEmployees", allEmployees.size());
            statistics.put("activeEmployees", activeEmployees.size());
            statistics.put("attritedEmployees", attritedEmployees.size());
            
            // Attrition rate
            if (allEmployees.size() > 0) {
                double attritionRate = (double) attritedEmployees.size() / allEmployees.size() * 100;
                statistics.put("attritionRate", attritionRate);
            } else {
                statistics.put("attritionRate", 0.0);
            }
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            log.error("Failed to fetch employee statistics", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
