import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  register: (userData) => api.post('/auth/register', userData),
  getCurrentUser: () => api.get('/auth/me'),
  changePassword: (passwordData) => api.post('/auth/change-password', passwordData),
  validateToken: (token) => api.post('/auth/validate', { token }),
  checkAdmin: () => api.get('/auth/check-admin'),
};

// Employee API
export const employeeAPI = {
  getAll: () => api.get('/employees'),
  getById: (id) => api.get(`/employees/${id}`),
  getByEmployeeId: (employeeId) => api.get(`/employees/employee-id/${employeeId}`),
  create: (employeeData) => api.post('/employees', employeeData),
  update: (id, employeeData) => api.put(`/employees/${id}`, employeeData),
  delete: (id) => api.delete(`/employees/${id}`),
  search: (name) => api.get(`/employees/search?name=${name}`),
  getByDepartment: (department) => api.get(`/employees/department/${department}`),
  getByAttritionStatus: (status) => api.get(`/employees/attrition/${status}`),
  getByAgeRange: (minAge, maxAge) => api.get(`/employees/age-range?minAge=${minAge}&maxAge=${maxAge}`),
  getBySalaryRange: (minSalary, maxSalary) => api.get(`/employees/salary-range?minSalary=${minSalary}&maxSalary=${maxSalary}`),
  getByExperienceRange: (minYears, maxYears) => api.get(`/employees/experience-range?minYears=${minYears}&maxYears=${maxYears}`),
  getStatistics: () => api.get('/employees/statistics'),
};

// Analytics API
export const analyticsAPI = {
  getDashboard: () => api.get('/analytics/dashboard'),
  getAttritionByDepartment: () => api.get('/analytics/attrition-by-department'),
  getAttritionByJobRole: () => api.get('/analytics/attrition-by-job-role'),
  getDemographics: () => api.get('/analytics/demographics'),
  getDepartmentStats: (department) => api.get(`/analytics/department-stats/${department}`),
  getSummary: () => api.get('/analytics/summary'),
  getTrends: () => api.get('/analytics/trends'),
  getPerformance: () => api.get('/analytics/performance'),
};

// Prediction API
export const predictionAPI = {
  predictEmployee: (employeeId) => api.get(`/prediction/employee/${employeeId}`),
  predictAll: () => api.get('/prediction/all'),
  predictDepartment: (department) => api.get(`/prediction/department/${department}`),
  getHighRisk: () => api.get('/prediction/high-risk'),
  getRiskDistribution: () => api.get('/prediction/risk-distribution'),
  getAccuracy: () => api.get('/prediction/accuracy'),
  trainModel: () => api.post('/prediction/train'),
  getSummary: () => api.get('/prediction/summary'),
  getRiskFactors: () => api.get('/prediction/risk-factors'),
  getRecommendations: () => api.get('/prediction/recommendations'),
};

// Reports API
export const reportsAPI = {
  exportEmployeesCSV: () => api.get('/reports/employees/csv', { responseType: 'blob' }),
  exportAttritionCSV: () => api.get('/reports/attrition/csv', { responseType: 'blob' }),
  exportDepartmentCSV: (department) => api.get(`/reports/department/${department}/csv`, { responseType: 'blob' }),
  getAnalyticsSummary: () => api.get('/reports/analytics/summary'),
  getStatistics: () => api.get('/reports/statistics'),
};

// Department API
export const departmentAPI = {
  getAll: () => api.get('/departments'),
  getActive: () => api.get('/departments/active'),
  getById: (id) => api.get(`/departments/${id}`),
  getByName: (name) => api.get(`/departments/name/${name}`),
  create: (departmentData) => api.post('/departments', departmentData),
  update: (id, departmentData) => api.put(`/departments/${id}`, departmentData),
  delete: (id) => api.delete(`/departments/${id}`),
  getStatistics: (departmentName) => api.get(`/departments/statistics/${departmentName}`),
  initialize: () => api.post('/departments/initialize'),
  updateCount: (departmentName) => api.post(`/departments/update-count/${departmentName}`),
  getSummary: () => api.get('/departments/summary'),
};

export default api;
