package com.hr.analytics.exception;

/**
 * Custom exception for business logic violations
 * Thrown when business rules are violated
 */
public class BusinessException extends RuntimeException {

    public BusinessException(String message) {
        super(message);
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }
}
