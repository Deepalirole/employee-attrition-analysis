import React, { useState, useEffect } from 'react';
import { reportsAPI, analyticsAPI } from '../services/api';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { 
  DocumentArrowDownIcon,
  DocumentTextIcon,
  ChartBarIcon,
  UserGroupIcon,
  FunnelIcon
} from '@heroicons/react/24/outline';

const ReportsPage = () => {
  const [analytics, setAnalytics] = useState(null);
  const [statistics, setStatistics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [exporting, setExporting] = useState(null);

  useEffect(() => {
    fetchReportsData();
  }, []);

  const fetchReportsData = async () => {
    try {
      setLoading(true);
      const [analyticsResponse, statsResponse] = await Promise.all([
        reportsAPI.getAnalyticsSummary(),
        reportsAPI.getStatistics()
      ]);
      
      setAnalytics(analyticsResponse.data);
      setStatistics(statsResponse.data);
    } catch (err) {
      console.error('Failed to fetch reports data:', err);
      setError('Failed to load reports data');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async (exportType, params = {}) => {
    try {
      setExporting(exportType);
      
      let response;
      switch (exportType) {
        case 'employees':
          response = await reportsAPI.exportEmployeesCSV();
          break;
        case 'attrition':
          response = await reportsAPI.exportAttritionCSV();
          break;
        case 'department':
          if (!params.department) return;
          response = await reportsAPI.exportDepartmentCSV(params.department);
          break;
        default:
          return;
      }

      // Create download link
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', getFileName(exportType, params));
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Export failed:', err);
      setError('Failed to export data');
    } finally {
      setExporting(null);
    }
  };

  const getFileName = (type, params) => {
    const date = new Date().toISOString().split('T')[0];
    switch (type) {
      case 'employees':
        return `employees_${date}.csv`;
      case 'attrition':
        return `attrition_report_${date}.csv`;
      case 'department':
        return `department_${params.department}_${date}.csv`;
      default:
        return `report_${date}.csv`;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-600 mb-4">{error}</div>
        <button onClick={fetchReportsData} className="btn btn-primary">
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="border-b border-gray-200 pb-5">
        <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
        <p className="mt-2 text-gray-600">Generate and export HR analytics reports</p>
      </div>

      {/* Export Options */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="card hover:shadow-lg transition-shadow duration-200">
          <div className="card-body">
            <div className="flex items-center mb-4">
              <DocumentArrowDownIcon className="h-8 w-8 text-primary-600 mr-3" />
              <h3 className="text-lg font-medium text-gray-900">Employee Data</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Export all employee data including personal and work information
            </p>
            <button
              onClick={() => handleExport('employees')}
              disabled={exporting === 'employees'}
              className="btn btn-primary w-full disabled:opacity-50"
            >
              {exporting === 'employees' ? (
                <LoadingSpinner size="small" />
              ) : (
                'Export CSV'
              )}
            </button>
          </div>
        </div>

        <div className="card hover:shadow-lg transition-shadow duration-200">
          <div className="card-body">
            <div className="flex items-center mb-4">
              <UserGroupIcon className="h-8 w-8 text-red-600 mr-3" />
              <h3 className="text-lg font-medium text-gray-900">Attrition Report</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Export detailed attrition report with employee departure information
            </p>
            <button
              onClick={() => handleExport('attrition')}
              disabled={exporting === 'attrition'}
              className="btn btn-danger w-full disabled:opacity-50"
            >
              {exporting === 'attrition' ? (
                <LoadingSpinner size="small" />
              ) : (
                'Export CSV'
              )}
            </button>
          </div>
        </div>

        <div className="card hover:shadow-lg transition-shadow duration-200">
          <div className="card-body">
            <div className="flex items-center mb-4">
              <ChartBarIcon className="h-8 w-8 text-green-600 mr-3" />
              <h3 className="text-lg font-medium text-gray-900">Department Report</h3>
            </div>
            <p className="text-gray-600 mb-4">
              Export employee data for a specific department
            </p>
            <select
              className="form-input mb-4"
              onChange={(e) => e.target.value && handleExport('department', { department: e.target.value })}
              disabled={exporting?.startsWith('department')}
            >
              <option value="">Select Department</option>
              {statistics?.departmentCounts && Object.keys(statistics.departmentCounts).map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
            <button
              onClick={() => {
                const select = document.querySelector('select');
                if (select.value) {
                  handleExport('department', { department: select.value });
                }
              }}
              disabled={exporting?.startsWith('department')}
              className="btn btn-success w-full disabled:opacity-50"
            >
              {exporting?.startsWith('department') ? (
                <LoadingSpinner size="small" />
              ) : (
                'Export CSV'
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Summary Statistics */}
      <div className="card">
        <div className="card-header">
          <h3 className="text-lg font-medium text-gray-900">Summary Statistics</h3>
        </div>
        <div className="card-body">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">{statistics?.totalEmployees || 0}</div>
              <div className="text-sm text-gray-500">Total Employees</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{statistics?.attritedEmployees || 0}</div>
              <div className="text-sm text-gray-500">Attrited Employees</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{statistics?.activeEmployees || 0}</div>
              <div className="text-sm text-gray-500">Active Employees</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary-600">
                {statistics?.totalEmployees > 0 
                  ? ((statistics.attritedEmployees / statistics.totalEmployees) * 100).toFixed(1)
                  : 0}%
              </div>
              <div className="text-sm text-gray-500">Attrition Rate</div>
            </div>
          </div>
        </div>
      </div>

      {/* Department Breakdown */}
      {statistics?.departmentCounts && (
        <div className="card">
          <div className="card-header">
            <h3 className="text-lg font-medium text-gray-900">Department Breakdown</h3>
          </div>
          <div className="card-body">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {Object.entries(statistics.departmentCounts).map(([department, count]) => (
                <div key={department} className="bg-gray-50 rounded-lg p-4">
                  <div className="text-lg font-bold text-gray-900">{count}</div>
                  <div className="text-sm text-gray-500">{department}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Gender Distribution */}
      {statistics?.genderCounts && (
        <div className="card">
          <div className="card-header">
            <h3 className="text-lg font-medium text-gray-900">Gender Distribution</h3>
          </div>
          <div className="card-body">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Object.entries(statistics.genderCounts).map(([gender, count]) => (
                <div key={gender} className="bg-gray-50 rounded-lg p-4">
                  <div className="text-lg font-bold text-gray-900">{count}</div>
                  <div className="text-sm text-gray-500">{gender}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Analytics Summary */}
      {analytics && (
        <div className="card">
          <div className="card-header">
            <h3 className="text-lg font-medium text-gray-900">Analytics Summary</h3>
          </div>
          <div className="card-body">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-500">Report Date</span>
                <span className="text-sm text-gray-900">{analytics.reportDate}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-500">Total Employees</span>
                <span className="text-sm text-gray-900">{analytics.totalEmployees}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-500">Attrition Count</span>
                <span className="text-sm text-gray-900">{analytics.attritionCount}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-500">Attrition Percentage</span>
                <span className="text-sm text-gray-900">{analytics.attritionPercentage?.toFixed(1)}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-500">Average Salary</span>
                <span className="text-sm text-gray-900">${analytics.averageSalary?.toFixed(0)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-500">Average Work Life Balance</span>
                <span className="text-sm text-gray-900">{analytics.averageWorkLifeBalance?.toFixed(1)}/5</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-500">Average Performance Rating</span>
                <span className="text-sm text-gray-900">{analytics.averagePerformanceRating?.toFixed(1)}/5</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-500">Overtime Employees</span>
                <span className="text-sm text-gray-900">{analytics.overtimeEmployees}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium text-gray-500">High Risk Employees</span>
                <span className="text-sm text-gray-900">{analytics.highRiskEmployees}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReportsPage;
