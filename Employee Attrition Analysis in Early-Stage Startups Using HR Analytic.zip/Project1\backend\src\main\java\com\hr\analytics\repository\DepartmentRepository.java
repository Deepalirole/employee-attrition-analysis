package com.hr.analytics.repository;

import com.hr.analytics.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Department entity
 * Provides database operations for department management
 */
@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {

    Optional<Department> findByName(String name);

    boolean existsByName(String name);

    List<Department> findByIsActive(Boolean isActive);

    @Query("SELECT d FROM Department d WHERE d.isActive = true ORDER BY d.name")
    List<Department> findActiveDepartmentsOrderByName();

    @Query("SELECT d.name, d.employeeCount FROM Department d WHERE d.isActive = true")
    List<Object[]> getDepartmentEmployeeCounts();

    @Query("SELECT COUNT(d) FROM Department d WHERE d.isActive = true")
    Long countActiveDepartments();
}
