import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { analyticsAPI, employeeAPI } from '../services/api';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { UsersIcon, UserGroupIcon, ChartBarIcon, ExclamationTriangleIcon } from '@heroicons/react/24/outline';

const Dashboard = () => {
  const [analytics, setAnalytics] = useState(null);
  const [employeeStats, setEmployeeStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const [analyticsResponse, statsResponse] = await Promise.all([
        analyticsAPI.getDashboard(),
        employeeAPI.getStatistics()
      ]);
      
      setAnalytics(analyticsResponse.data);
      setEmployeeStats(statsResponse.data);
    } catch (err) {
      console.error('Failed to fetch dashboard data:', err);
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-600 mb-4">{error}</div>
        <button
          onClick={fetchDashboardData}
          className="btn btn-primary"
        >
          Retry
        </button>
      </div>
    );
  }

  const statCards = [
    {
      name: 'Total Employees',
      value: analytics?.totalEmployees || 0,
      icon: UsersIcon,
      color: 'bg-blue-500',
      link: '/employees'
    },
    {
      name: 'Attrition Count',
      value: analytics?.attritionCount || 0,
      icon: UserGroupIcon,
      color: 'bg-red-500',
      link: '/employees?attrition=true'
    },
    {
      name: 'Attrition Rate',
      value: `${analytics?.attritionPercentage?.toFixed(1) || 0}%`,
      icon: ChartBarIcon,
      color: 'bg-yellow-500',
      link: '/analytics'
    },
    {
      name: 'High Risk Employees',
      value: analytics?.highRiskEmployees || 0,
      icon: ExclamationTriangleIcon,
      color: 'bg-orange-500',
      link: '/prediction'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="border-b border-gray-200 pb-5">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="mt-2 text-gray-600">Overview of HR analytics and key metrics</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat) => (
          <Link
            key={stat.name}
            to={stat.link}
            className="group"
          >
            <div className="card hover:shadow-lg transition-shadow duration-200">
              <div className="p-6">
                <div className="flex items-center">
                  <div className={`flex-shrink-0 rounded-md p-3 ${stat.color}`}>
                    <stat.icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        {stat.name}
                      </dt>
                      <dd className="text-lg font-medium text-gray-900">
                        {stat.value}
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="card">
        <div className="card-header">
          <h3 className="text-lg font-medium text-gray-900">Quick Actions</h3>
        </div>
        <div className="card-body">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Link
              to="/employees/add"
              className="btn btn-primary w-full justify-center"
            >
              Add New Employee
            </Link>
            <Link
              to="/analytics"
              className="btn btn-secondary w-full justify-center"
            >
              View Analytics
            </Link>
            <Link
              to="/prediction"
              className="btn btn-warning w-full justify-center"
            >
              Run Predictions
            </Link>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Overview */}
        <div className="card">
          <div className="card-header">
            <h3 className="text-lg font-medium text-gray-900">Department Overview</h3>
          </div>
          <div className="card-body">
            {analytics?.departmentWiseAttrition && Object.entries(analytics.departmentWiseAttrition).length > 0 ? (
              <div className="space-y-3">
                {Object.entries(analytics.departmentWiseAttrition).slice(0, 5).map(([department, count]) => (
                  <div key={department} className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-primary-500 rounded-full mr-3"></div>
                      <span className="text-sm font-medium text-gray-900">{department}</span>
                    </div>
                    <span className="text-sm text-gray-500">{count} employees</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-sm">No department data available</p>
            )}
          </div>
        </div>

        {/* Key Metrics */}
        <div className="card">
          <div className="card-header">
            <h3 className="text-lg font-medium text-gray-900">Key Metrics</h3>
          </div>
          <div className="card-body">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500">Average Salary</span>
                <span className="text-sm font-bold text-gray-900">
                  ${analytics?.averageSalary?.toFixed(0) || 0}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500">Avg Work-Life Balance</span>
                <span className="text-sm font-bold text-gray-900">
                  {analytics?.averageWorkLifeBalance?.toFixed(1) || 0}/5
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500">Avg Performance Rating</span>
                <span className="text-sm font-bold text-gray-900">
                  {analytics?.averagePerformanceRating?.toFixed(1) || 0}/5
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500">Overtime Employees</span>
                <span className="text-sm font-bold text-gray-900">
                  {analytics?.overtimeEmployees || 0}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Gender Distribution */}
      <div className="card">
        <div className="card-header">
          <h3 className="text-lg font-medium text-gray-900">Gender Distribution</h3>
        </div>
        <div className="card-body">
          {analytics?.genderDistribution && Object.entries(analytics.genderDistribution).length > 0 ? (
            <div className="grid grid-cols-2 gap-4">
              {Object.entries(analytics.genderDistribution).map(([gender, count]) => (
                <div key={gender} className="text-center">
                  <div className="text-2xl font-bold text-gray-900">{count}</div>
                  <div className="text-sm text-gray-500">{gender}</div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500 text-sm">No gender distribution data available</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
