package com.hr.analytics.controller;

import com.hr.analytics.dto.AnalyticsDTO;
import com.hr.analytics.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST Controller for HR Analytics operations
 * Provides dashboard metrics and statistical analysis
 */
@RestController
@RequestMapping("/analytics")
@RequiredArgsConstructor
@Slf4j
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    /**
     * Get comprehensive dashboard analytics
     */
    @GetMapping("/dashboard")
    public ResponseEntity<AnalyticsDTO> getDashboardAnalytics() {
        log.info("Fetching dashboard analytics");
        
        try {
            AnalyticsDTO analytics = analyticsService.getDashboardAnalytics();
            return ResponseEntity.ok(analytics);
        } catch (Exception e) {
            log.error("Failed to fetch dashboard analytics", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get attrition rate by department
     */
    @GetMapping("/attrition-by-department")
    public ResponseEntity<Map<String, Double>> getAttritionRateByDepartment() {
        log.info("Fetching attrition rate by department");
        
        try {
            Map<String, Double> attritionRates = analyticsService.getAttritionRateByDepartment();
            return ResponseEntity.ok(attritionRates);
        } catch (Exception e) {
            log.error("Failed to fetch attrition rate by department", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get attrition by job role
     */
    @GetMapping("/attrition-by-job-role")
    public ResponseEntity<Map<String, Long>> getAttritionByJobRole() {
        log.info("Fetching attrition by job role");
        
        try {
            Map<String, Long> attritionByRole = analyticsService.getAttritionByJobRole();
            return ResponseEntity.ok(attritionByRole);
        } catch (Exception e) {
            log.error("Failed to fetch attrition by job role", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get employee demographics
     */
    @GetMapping("/demographics")
    public ResponseEntity<Map<String, Object>> getEmployeeDemographics() {
        log.info("Fetching employee demographics");
        
        try {
            Map<String, Object> demographics = analyticsService.getEmployeeDemographics();
            return ResponseEntity.ok(demographics);
        } catch (Exception e) {
            log.error("Failed to fetch employee demographics", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get department-wise statistics
     */
    @GetMapping("/department-stats/{department}")
    public ResponseEntity<?> getDepartmentStatistics(@PathVariable String department) {
        log.info("Fetching statistics for department: {}", department);
        
        try {
            Map<String, Object> stats = new HashMap<>();
            
            // Get department-wise attrition
            Map<String, Double> attritionByDept = analyticsService.getAttritionRateByDepartment();
            if (attritionByDept.containsKey(department)) {
                stats.put("attritionRate", attritionByDept.get(department));
            }
            
            // Get attrition by job role for this department
            Map<String, Long> attritionByRole = analyticsService.getAttritionByJobRole();
            stats.put("attritionByRole", attritionByRole);
            
            return ResponseEntity.ok(stats);
        } catch (Exception e) {
            log.error("Failed to fetch statistics for department: {}", department, e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get summary metrics
     */
    @GetMapping("/summary")
    public ResponseEntity<?> getSummaryMetrics() {
        log.info("Fetching summary metrics");
        
        try {
            AnalyticsDTO analytics = analyticsService.getDashboardAnalytics();
            
            Map<String, Object> summary = new HashMap<>();
            summary.put("totalEmployees", analytics.getTotalEmployees());
            summary.put("attritionCount", analytics.getAttritionCount());
            summary.put("attritionPercentage", analytics.getAttritionPercentage());
            summary.put("averageSalary", analytics.getAverageSalary());
            summary.put("averageWorkLifeBalance", analytics.getAverageWorkLifeBalance());
            summary.put("averagePerformanceRating", analytics.getAveragePerformanceRating());
            summary.put("overtimeEmployees", analytics.getOvertimeEmployees());
            summary.put("highRiskEmployees", analytics.getHighRiskEmployees());
            
            return ResponseEntity.ok(summary);
        } catch (Exception e) {
            log.error("Failed to fetch summary metrics", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get trend data for charts
     */
    @GetMapping("/trends")
    public ResponseEntity<?> getTrendData() {
        log.info("Fetching trend data");
        
        try {
            AnalyticsDTO analytics = analyticsService.getDashboardAnalytics();
            
            Map<String, Object> trends = new HashMap<>();
            trends.put("monthlyTrends", analytics.getMonthlyTrends());
            trends.put("departmentWiseAttrition", analytics.getDepartmentWiseAttrition());
            trends.put("genderDistribution", analytics.getGenderDistribution());
            trends.put("salaryWiseAttrition", analytics.getSalaryWiseAttrition());
            trends.put("experienceAnalysis", analytics.getExperienceAnalysis());
            
            return ResponseEntity.ok(trends);
        } catch (Exception e) {
            log.error("Failed to fetch trend data", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get performance metrics
     */
    @GetMapping("/performance")
    public ResponseEntity<?> getPerformanceMetrics() {
        log.info("Fetching performance metrics");
        
        try {
            AnalyticsDTO analytics = analyticsService.getDashboardAnalytics();
            
            Map<String, Object> performance = new HashMap<>();
            performance.put("averagePerformanceRating", analytics.getAveragePerformanceRating());
            performance.put("averageWorkLifeBalance", analytics.getAverageWorkLifeBalance());
            performance.put("averageSalary", analytics.getAverageSalary());
            performance.put("overtimeEmployees", analytics.getOvertimeEmployees());
            performance.put("highRiskEmployees", analytics.getHighRiskEmployees());
            
            return ResponseEntity.ok(performance);
        } catch (Exception e) {
            log.error("Failed to fetch performance metrics", e);
            return ResponseEntity.internalServerError().build();
        }
    }
}
