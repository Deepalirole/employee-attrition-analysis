-- HR Analytics Database Schema
-- Employee Attrition Analysis System

-- Create database
CREATE DATABASE IF NOT EXISTS hr_analytics_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hr_analytics_db;

-- Drop tables if they exist (for fresh start)
DROP TABLE IF EXISTS attrition_records;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS departments;
DROP TABLE IF EXISTS users;

-- Create departments table
CREATE TABLE departments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(500),
    head_of_department VARCHAR(100),
    employee_count INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_department_name (name),
    INDEX idx_department_active (is_active)
);

-- Create users table for authentication
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'USER',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_username (username),
    INDEX idx_user_email (email),
    INDEX idx_user_active (is_active)
);

-- Create employees table
CREATE TABLE employees (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    employee_id VARCHAR(50) NOT NULL UNIQUE,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    gender VARCHAR(20) NOT NULL,
    age INT NOT NULL CHECK (age >= 18 AND age <= 65),
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    department VARCHAR(100) NOT NULL,
    job_role VARCHAR(100) NOT NULL,
    salary DECIMAL(10,2) NOT NULL CHECK (salary > 0),
    years_at_company INT NOT NULL CHECK (years_at_company >= 0),
    overtime BOOLEAN NOT NULL DEFAULT FALSE,
    work_life_balance INT NOT NULL CHECK (work_life_balance >= 1 AND work_life_balance <= 5),
    distance_from_home INT NOT NULL CHECK (distance_from_home >= 0),
    performance_rating INT NOT NULL CHECK (performance_rating >= 1 AND performance_rating <= 5),
    attrition_status BOOLEAN NOT NULL DEFAULT FALSE,
    joining_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_employee_id (employee_id),
    INDEX idx_employee_email (email),
    INDEX idx_employee_department (department),
    INDEX idx_employee_job_role (job_role),
    INDEX idx_employee_attrition (attrition_status),
    INDEX idx_employee_age (age),
    INDEX idx_employee_salary (salary),
    INDEX idx_employee_joining_date (joining_date)
);

-- Create attrition_records table for tracking attrition history
CREATE TABLE attrition_records (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    employee_id BIGINT NOT NULL,
    attrition_date DATE NOT NULL,
    attrition_reason VARCHAR(500),
    final_salary DECIMAL(10,2),
    exit_interview_notes TEXT,
    replacement_hired BOOLEAN DEFAULT FALSE,
    replacement_date DATE,
    created_at DATE NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    INDEX idx_attrition_employee (employee_id),
    INDEX idx_attrition_date (attrition_date),
    INDEX idx_attrition_replacement (replacement_hired)
);

-- Insert default admin user (password: admin123 - will be hashed by Spring Security)
INSERT INTO users (username, password, email, first_name, last_name, role, is_active) VALUES
('admin', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@hranalytics.com', 'Admin', 'User', 'ADMIN', TRUE);

-- Insert default departments
INSERT INTO departments (name, description, is_active) VALUES
('Engineering', 'Software development and IT infrastructure', TRUE),
('Sales', 'Sales and business development', TRUE),
('Marketing', 'Marketing and brand management', TRUE),
('Human Resources', 'HR operations and employee relations', TRUE),
('Finance', 'Financial planning and accounting', TRUE),
('Operations', 'Business operations and logistics', TRUE),
('Customer Support', 'Customer service and support', TRUE),
('IT', 'Information technology and systems', TRUE);

-- Insert sample employee data for testing
INSERT INTO employees (
    employee_id, first_name, last_name, gender, age, email, phone, department, job_role, 
    salary, years_at_company, overtime, work_life_balance, distance_from_home, 
    performance_rating, attrition_status, joining_date
) VALUES
('EMP001', 'John', 'Smith', 'Male', 32, 'john.smith@company.com', '555-0101', 'Engineering', 'Software Engineer', 75000.00, 3, TRUE, 3, 15, 4, FALSE, '2021-01-15'),
('EMP002', 'Sarah', 'Johnson', 'Female', 28, 'sarah.johnson@company.com', '555-0102', 'Sales', 'Sales Representative', 55000.00, 2, TRUE, 2, 25, 3, FALSE, '2022-03-20'),
('EMP003', 'Michael', 'Brown', 'Male', 45, 'michael.brown@company.com', '555-0103', 'Finance', 'Financial Analyst', 85000.00, 8, FALSE, 4, 10, 5, FALSE, '2016-06-10'),
('EMP004', 'Emily', 'Davis', 'Female', 35, 'emily.davis@company.com', '555-0104', 'Marketing', 'Marketing Manager', 95000.00, 5, TRUE, 2, 30, 4, TRUE, '2019-08-15'),
('EMP005', 'David', 'Wilson', 'Male', 29, 'david.wilson@company.com', '555-0105', 'Engineering', 'Junior Developer', 60000.00, 1, TRUE, 1, 20, 3, FALSE, '2023-05-01'),
('EMP006', 'Jessica', 'Miller', 'Female', 38, 'jessica.miller@company.com', '555-0106', 'Human Resources', 'HR Manager', 80000.00, 6, FALSE, 4, 12, 5, FALSE, '2018-02-20'),
('EMP007', 'Robert', 'Taylor', 'Male', 41, 'robert.taylor@company.com', '555-0107', 'Operations', 'Operations Manager', 90000.00, 7, FALSE, 3, 8, 4, FALSE, '2017-04-10'),
('EMP008', 'Lisa', 'Anderson', 'Female', 26, 'lisa.anderson@company.com', '555-0108', 'Customer Support', 'Support Specialist', 45000.00, 1, TRUE, 2, 35, 3, FALSE, '2023-07-15'),
('EMP009', 'James', 'Thomas', 'Male', 33, 'james.thomas@company.com', '555-0109', 'IT', 'System Administrator', 70000.00, 4, TRUE, 3, 18, 4, FALSE, '2020-09-12'),
('EMP010', 'Jennifer', 'Jackson', 'Female', 30, 'jennifer.jackson@company.com', '555-0110', 'Sales', 'Account Manager', 65000.00, 3, FALSE, 4, 22, 5, FALSE, '2021-11-05');

-- Insert some attrition records for employees who have left
INSERT INTO attrition_records (
    employee_id, attrition_date, attrition_reason, final_salary, 
    exit_interview_notes, replacement_hired, replacement_date, created_at
) VALUES
(4, '2023-12-01', 'Better opportunity', 95000.00, 'Found a higher paying position with better benefits', FALSE, NULL, '2023-12-01');

-- Create views for common queries
CREATE VIEW employee_summary AS
SELECT 
    e.id,
    e.employee_id,
    e.first_name,
    e.last_name,
    e.department,
    e.job_role,
    e.salary,
    e.attrition_status,
    e.joining_date,
    d.name as department_name
FROM employees e
LEFT JOIN departments d ON e.department = d.name;

CREATE VIEW attrition_summary AS
SELECT 
    d.name as department,
    COUNT(e.id) as total_employees,
    SUM(CASE WHEN e.attrition_status = TRUE THEN 1 ELSE 0 END) as attrition_count,
    ROUND(
        (SUM(CASE WHEN e.attrition_status = TRUE THEN 1 ELSE 0 END) * 100.0) / 
        COUNT(e.id), 2
    ) as attrition_rate,
    AVG(e.salary) as average_salary,
    AVG(e.work_life_balance) as avg_work_life_balance,
    AVG(e.performance_rating) as avg_performance_rating
FROM employees e
LEFT JOIN departments d ON e.department = d.name
GROUP BY d.name
ORDER BY attrition_rate DESC;

-- Create stored procedures for common operations
DELIMITER //

CREATE PROCEDURE GetEmployeeStatistics()
BEGIN
    SELECT 
        COUNT(*) as total_employees,
        SUM(CASE WHEN attrition_status = TRUE THEN 1 ELSE 0 END) as attrition_count,
        ROUND(
            (SUM(CASE WHEN attrition_status = TRUE THEN 1 ELSE 0 END) * 100.0) / 
            COUNT(*), 2
        ) as attrition_percentage,
        AVG(salary) as average_salary,
        AVG(work_life_balance) as avg_work_life_balance,
        AVG(performance_rating) as avg_performance_rating,
        SUM(CASE WHEN overtime = TRUE THEN 1 ELSE 0 END) as overtime_employees
    FROM employees;
END//

CREATE PROCEDURE GetDepartmentAnalytics(IN dept_name VARCHAR(100))
BEGIN
    SELECT 
        COUNT(*) as total_employees,
        SUM(CASE WHEN attrition_status = TRUE THEN 1 ELSE 0 END) as attrition_count,
        ROUND(
            (SUM(CASE WHEN attrition_status = TRUE THEN 1 ELSE 0 END) * 100.0) / 
            COUNT(*), 2
        ) as attrition_rate,
        AVG(salary) as average_salary,
        AVG(work_life_balance) as avg_work_life_balance,
        AVG(performance_rating) as avg_performance_rating,
        AVG(age) as avg_age,
        AVG(years_at_company) as avg_experience
    FROM employees
    WHERE department = dept_name;
END//

DELIMITER ;

-- Create triggers for maintaining department employee counts
DELIMITER //

CREATE TRIGGER update_department_count_after_insert
AFTER INSERT ON employees
FOR EACH ROW
BEGIN
    UPDATE departments 
    SET employee_count = employee_count + 1 
    WHERE name = NEW.department;
END//

CREATE TRIGGER update_department_count_after_delete
AFTER DELETE ON employees
FOR EACH ROW
BEGIN
    UPDATE departments 
    SET employee_count = employee_count - 1 
    WHERE name = OLD.department;
END//

CREATE TRIGGER update_department_count_after_update
AFTER UPDATE ON employees
FOR EACH ROW
BEGIN
    IF OLD.department != NEW.department THEN
        UPDATE departments 
        SET employee_count = employee_count - 1 
        WHERE name = OLD.department;
        
        UPDATE departments 
        SET employee_count = employee_count + 1 
        WHERE name = NEW.department;
    END IF;
END//

DELIMITER ;

-- Update department employee counts based on existing data
UPDATE departments d 
SET employee_count = (
    SELECT COUNT(*) 
    FROM employees e 
    WHERE e.department = d.name
);

-- Grant permissions (adjust as needed for your environment)
-- GRANT ALL PRIVILEGES ON hr_analytics_db.* TO 'hr_user'@'localhost' IDENTIFIED BY 'password';
-- FLUSH PRIVILEGES;

-- Display summary information
SELECT 'Database setup completed successfully!' as status;
SELECT COUNT(*) as total_departments FROM departments;
SELECT COUNT(*) as total_users FROM users;
SELECT COUNT(*) as total_employees FROM employees;
SELECT COUNT(*) as total_attrition_records FROM attrition_records;
