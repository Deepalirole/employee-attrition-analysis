package com.hr.analytics.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Prediction DTO for ML attrition prediction
 * Contains prediction results and confidence scores
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class PredictionDTO {

    private String employeeId;
    private String employeeName;
    private Boolean willLeave;
    private Double confidenceScore;
    private String riskLevel;
    private String factors;
    private String recommendations;

    public String getRiskLevel() {
        if (confidenceScore >= 0.8) {
            return "High";
        } else if (confidenceScore >= 0.6) {
            return "Medium";
        } else {
            return "Low";
        }
    }
}
