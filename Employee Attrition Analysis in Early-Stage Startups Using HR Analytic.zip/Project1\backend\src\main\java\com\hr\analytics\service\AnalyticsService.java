package com.hr.analytics.service;

import com.hr.analytics.dto.AnalyticsDTO;
import com.hr.analytics.repository.EmployeeRepository;
import com.hr.analytics.repository.AttritionRecordRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Service class for HR Analytics
 * Provides statistical analysis and dashboard metrics
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class AnalyticsService {

    private final EmployeeRepository employeeRepository;
    private final AttritionRecordRepository attritionRecordRepository;

    /**
     * Get comprehensive analytics for dashboard
     */
    public AnalyticsDTO getDashboardAnalytics() {
        log.info("Generating dashboard analytics");
        
        AnalyticsDTO analytics = new AnalyticsDTO();
        
        // Basic counts
        analytics.setTotalEmployees(employeeRepository.count());
        analytics.setAttritionCount(employeeRepository.countByAttritionStatusTrue());
        
        // Calculate attrition percentage
        if (analytics.getTotalEmployees() > 0) {
            analytics.setAttritionPercentage(
                (double) analytics.getAttritionCount() / analytics.getTotalEmployees() * 100
            );
        } else {
            analytics.setAttritionPercentage(0.0);
        }
        
        // Department-wise attrition
        analytics.setDepartmentWiseAttrition(getDepartmentWiseAttrition());
        
        // Gender distribution
        analytics.setGenderDistribution(getGenderDistribution());
        
        // Salary-wise attrition
        analytics.setSalaryWiseAttrition(getSalaryWiseAttrition());
        
        // Experience analysis
        analytics.setExperienceAnalysis(getExperienceAnalysis());
        
        // Monthly trends
        analytics.setMonthlyTrends(getMonthlyTrends());
        
        // Average metrics
        analytics.setAverageSalary(employeeRepository.getAverageSalary());
        analytics.setAverageWorkLifeBalance(employeeRepository.getAverageWorkLifeBalance());
        analytics.setAveragePerformanceRating(employeeRepository.getAveragePerformanceRating());
        
        // Overtime employees count
        analytics.setOvertimeEmployees(employeeRepository.countByOvertimeTrue());
        
        // High risk employees (based on multiple factors)
        analytics.setHighRiskEmployees(calculateHighRiskEmployees());
        
        log.info("Dashboard analytics generated successfully");
        return analytics;
    }

    /**
     * Get department-wise attrition statistics
     */
    private Map<String, Long> getDepartmentWiseAttrition() {
        List<Object[]> results = employeeRepository.getDepartmentWiseAttrition();
        return results.stream()
                .collect(Collectors.toMap(
                    result -> (String) result[0],
                    result -> (Long) result[1]
                ));
    }

    /**
     * Get gender distribution
     */
    private Map<String, Long> getGenderDistribution() {
        List<Object[]> results = employeeRepository.getGenderDistribution();
        return results.stream()
                .collect(Collectors.toMap(
                    result -> (String) result[0],
                    result -> (Long) result[1]
                ));
    }

    /**
     * Get salary-wise attrition (grouped by salary ranges)
     */
    private Map<String, Double> getSalaryWiseAttrition() {
        Map<String, Double> salaryWiseAttrition = new HashMap<>();
        
        // Define salary ranges
        String[] salaryRanges = {"0-30000", "30001-50000", "50001-70000", "70001-100000", "100000+"};
        
        for (String range : salaryRanges) {
            String[] bounds = range.split("-");
            if (bounds.length == 2) {
                Double minSalary = Double.parseDouble(bounds[0]);
                Double maxSalary = bounds[1].equals("+") ? Double.MAX_VALUE : Double.parseDouble(bounds[1]);
                
                Long totalInRange = employeeRepository.findBySalaryRange(minSalary, maxSalary).stream().count();
                Long attritionInRange = employeeRepository.findBySalaryRange(minSalary, maxSalary).stream()
                    .filter(emp -> emp.getAttritionStatus())
                    .count();
                
                if (totalInRange > 0) {
                    salaryWiseAttrition.put(range, (double) attritionInRange / totalInRange * 100);
                } else {
                    salaryWiseAttrition.put(range, 0.0);
                }
            }
        }
        
        return salaryWiseAttrition;
    }

    /**
     * Get experience analysis (grouped by years at company)
     */
    private Map<String, Long> getExperienceAnalysis() {
        Map<String, Long> experienceAnalysis = new HashMap<>();
        
        // Define experience ranges
        String[] experienceRanges = {"0-1", "2-5", "6-10", "11-20", "20+"};
        
        for (String range : experienceRanges) {
            String[] bounds = range.split("-");
            if (bounds.length == 2) {
                Integer minYears = Integer.parseInt(bounds[0]);
                Integer maxYears = bounds[1].equals("+") ? Integer.MAX_VALUE : Integer.parseInt(bounds[1]);
                
                Long count = employeeRepository.findByYearsAtCompanyRange(minYears, maxYears).stream().count();
                experienceAnalysis.put(range, count);
            }
        }
        
        return experienceAnalysis;
    }

    /**
     * Get monthly attrition trends for the current year
     */
    private Map<String, Long> getMonthlyTrends() {
        Map<String, Long> monthlyTrends = new HashMap<>();
        int currentYear = java.time.Year.now().getValue();
        
        List<Object[]> results = attritionRecordRepository.getMonthlyAttritionByYear(currentYear);
        
        // Initialize all months with 0
        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        for (String month : months) {
            monthlyTrends.put(month, 0L);
        }
        
        // Fill in actual data
        for (Object[] result : results) {
            Integer month = (Integer) result[0];
            Long count = (Long) result[1];
            monthlyTrends.put(months[month - 1], count);
        }
        
        return monthlyTrends;
    }

    /**
     * Calculate high-risk employees based on multiple factors
     */
    private Long calculateHighRiskEmployees() {
        // High risk criteria:
        // - Low work-life balance (1-2)
        // - High overtime
        // - Low performance rating (1-2)
        // - High distance from home (>20)
        
        return employeeRepository.findAll().stream()
            .filter(emp -> emp.getWorkLifeBalance() <= 2)
            .filter(emp -> emp.getOvertime())
            .filter(emp -> emp.getPerformanceRating() <= 2)
            .filter(emp -> emp.getDistanceFromHome() > 20)
            .filter(emp -> !emp.getAttritionStatus()) // Only active employees
            .count();
    }

    /**
     * Get attrition rate by department
     */
    public Map<String, Double> getAttritionRateByDepartment() {
        Map<String, Double> attritionRates = new HashMap<>();
        
        List<String> departments = employeeRepository.findAll().stream()
            .map(Employee::getDepartment)
            .distinct()
            .collect(Collectors.toList());
        
        for (String department : departments) {
            Long totalInDept = employeeRepository.findByDepartment(department).stream().count();
            Long attritionInDept = employeeRepository.findByDepartmentAndAttritionStatus(department, true).stream().count();
            
            if (totalInDept > 0) {
                attritionRates.put(department, (double) attritionInDept / totalInDept * 100);
            } else {
                attritionRates.put(department, 0.0);
            }
        }
        
        return attritionRates;
    }

    /**
     * Get attrition by job role
     */
    public Map<String, Long> getAttritionByJobRole() {
        List<Object[]> results = employeeRepository.getJobRoleWiseAttrition();
        return results.stream()
            .collect(Collectors.toMap(
                result -> (String) result[0],
                result -> (Long) result[1]
            ));
    }

    /**
     * Get employee demographics summary
     */
    public Map<String, Object> getEmployeeDemographics() {
        Map<String, Object> demographics = new HashMap<>();
        
        // Age groups
        Map<String, Long> ageGroups = new HashMap<>();
        ageGroups.put("18-25", employeeRepository.findByAgeRange(18, 25).stream().count());
        ageGroups.put("26-35", employeeRepository.findByAgeRange(26, 35).stream().count());
        ageGroups.put("36-45", employeeRepository.findByAgeRange(36, 45).stream().count());
        ageGroups.put("46-55", employeeRepository.findByAgeRange(46, 55).stream().count());
        ageGroups.put("56-65", employeeRepository.findByAgeRange(56, 65).stream().count());
        
        demographics.put("ageGroups", ageGroups);
        demographics.put("genderDistribution", getGenderDistribution());
        demographics.put("departmentDistribution", getDepartmentDistribution());
        
        return demographics;
    }

    /**
     * Get department distribution
     */
    private Map<String, Long> getDepartmentDistribution() {
        return employeeRepository.findAll().stream()
            .collect(Collectors.groupingBy(
                Employee::getDepartment,
                Collectors.counting()
            ));
    }
}
