package com.hr.analytics.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

/**
 * Data Transfer Object for Employee entity
 * Used for API request/response handling
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDTO {

    private Long id;

    @NotBlank(message = "Employee ID is required")
    private String employeeId;

    @NotBlank(message = "First name is required")
    @Size(max = 50, message = "First name must not exceed 50 characters")
    private String firstName;

    @NotBlank(message = "Last name is required")
    @Size(max = 50, message = "Last name must not exceed 50 characters")
    private String lastName;

    @NotBlank(message = "Gender is required")
    private String gender;

    @NotNull(message = "Age is required")
    @Min(value = 18, message = "Age must be at least 18")
    @Max(value = 65, message = "Age must not exceed 65")
    private Integer age;

    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    private String email;

    private String phone;

    @NotBlank(message = "Department is required")
    private String department;

    @NotBlank(message = "Job role is required")
    private String jobRole;

    @NotNull(message = "Salary is required")
    @DecimalMin(value = "0.0", message = "Salary must be positive")
    private Double salary;

    @NotNull(message = "Years at company is required")
    @Min(value = 0, message = "Years at company cannot be negative")
    private Integer yearsAtCompany;

    @NotNull(message = "Overtime information is required")
    private Boolean overtime;

    @NotNull(message = "Work life balance rating is required")
    @Min(value = 1, message = "Work life balance must be between 1 and 5")
    @Max(value = 5, message = "Work life balance must be between 1 and 5")
    private Integer workLifeBalance;

    @NotNull(message = "Distance from home is required")
    @Min(value = 0, message = "Distance from home cannot be negative")
    private Integer distanceFromHome;

    @NotNull(message = "Performance rating is required")
    @Min(value = 1, message = "Performance rating must be between 1 and 5")
    @Max(value = 5, message = "Performance rating must be between 1 and 5")
    private Integer performanceRating;

    private Boolean attritionStatus = false;

    @NotNull(message = "Joining date is required")
    @Past(message = "Joining date must be in the past")
    private LocalDate joiningDate;
}
