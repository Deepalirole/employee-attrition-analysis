package com.hr.analytics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main application class for HR Analytics System
 * Entry point for the Spring Boot application
 */
@SpringBootApplication
public class HrAnalyticsApplication {

    public static void main(String[] args) {
        SpringApplication.run(HrAnalyticsApplication.class, args);
    }

}
