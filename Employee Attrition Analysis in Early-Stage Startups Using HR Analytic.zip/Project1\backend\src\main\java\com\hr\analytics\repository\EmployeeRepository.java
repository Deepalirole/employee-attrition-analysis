package com.hr.analytics.repository;

import com.hr.analytics.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for Employee entity
 * Provides database operations for employee management
 */
@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    Optional<Employee> findByEmployeeId(String employeeId);

    Optional<Employee> findByEmail(String email);

    List<Employee> findByDepartment(String department);

    List<Employee> findByJobRole(String jobRole);

    List<Employee> findByAttritionStatus(Boolean attritionStatus);

    List<Employee> findByDepartmentAndAttritionStatus(String department, Boolean attritionStatus);

    @Query("SELECT e FROM Employee e WHERE e.firstName LIKE %:name% OR e.lastName LIKE %:name%")
    List<Employee> findByNameContaining(@Param("name") String name);

    @Query("SELECT COUNT(e) FROM Employee e WHERE e.attritionStatus = true")
    Long countByAttritionStatusTrue();

    @Query("SELECT COUNT(e) FROM Employee e WHERE e.department = :department AND e.attritionStatus = true")
    Long countByDepartmentAndAttritionStatus(@Param("department") String department);

    @Query("SELECT e.department, COUNT(e) FROM Employee e WHERE e.attritionStatus = true GROUP BY e.department")
    List<Object[]> getDepartmentWiseAttrition();

    @Query("SELECT e.gender, COUNT(e) FROM Employee e GROUP BY e.gender")
    List<Object[]> getGenderDistribution();

    @Query("SELECT e.jobRole, COUNT(e) FROM Employee e WHERE e.attritionStatus = true GROUP BY e.jobRole")
    List<Object[]> getJobRoleWiseAttrition();

    @Query("SELECT AVG(e.salary) FROM Employee e")
    Double getAverageSalary();

    @Query("SELECT AVG(e.workLifeBalance) FROM Employee e")
    Double getAverageWorkLifeBalance();

    @Query("SELECT AVG(e.performanceRating) FROM Employee e")
    Double getAveragePerformanceRating();

    @Query("SELECT COUNT(e) FROM Employee e WHERE e.overtime = true")
    Long countByOvertimeTrue();

    @Query("SELECT e FROM Employee e WHERE e.age BETWEEN :minAge AND :maxAge")
    List<Employee> findByAgeRange(@Param("minAge") Integer minAge, @Param("maxAge") Integer maxAge);

    @Query("SELECT e FROM Employee e WHERE e.salary BETWEEN :minSalary AND :maxSalary")
    List<Employee> findBySalaryRange(@Param("minSalary") Double minSalary, @Param("maxSalary") Double maxSalary);

    @Query("SELECT e FROM Employee e WHERE e.yearsAtCompany BETWEEN :minYears AND :maxYears")
    List<Employee> findByYearsAtCompanyRange(@Param("minYears") Integer minYears, @Param("maxYears") Integer maxYears);
}
