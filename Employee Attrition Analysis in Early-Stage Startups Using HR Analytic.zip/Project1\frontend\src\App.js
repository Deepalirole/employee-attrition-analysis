import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import EmployeeList from './pages/EmployeeList';
import AddEmployee from './pages/AddEmployee';
import EditEmployee from './pages/EditEmployee';
import AnalyticsDashboard from './pages/AnalyticsDashboard';
import PredictionPage from './pages/PredictionPage';
import ReportsPage from './pages/ReportsPage';
import Layout from './components/Layout';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={
              <ProtectedRoute>
                <Layout>
                  <Routes>
                    <Route index element={<Navigate to="/dashboard" replace />} />
                    <Route path="dashboard" element={<Dashboard />} />
                    <Route path="employees" element={<EmployeeList />} />
                    <Route path="employees/add" element={<AddEmployee />} />
                    <Route path="employees/edit/:id" element={<EditEmployee />} />
                    <Route path="analytics" element={<AnalyticsDashboard />} />
                    <Route path="prediction" element={<PredictionPage />} />
                    <Route path="reports" element={<ReportsPage />} />
                  </Routes>
                </Layout>
              </ProtectedRoute>
            } />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
