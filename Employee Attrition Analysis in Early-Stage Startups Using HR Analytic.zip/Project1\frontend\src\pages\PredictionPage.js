import React, { useState, useEffect } from 'react';
import { predictionAPI, employeeAPI } from '../services/api';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { 
  BrainIcon, 
  ExclamationTriangleIcon, 
  CheckCircleIcon,
  FunnelIcon,
  UserGroupIcon,
  ChartBarIcon
} from '@heroicons/react/24/outline';

const PredictionPage = () => {
  const [allPredictions, setAllPredictions] = useState([]);
  const [highRiskEmployees, setHighRiskEmployees] = useState([]);
  const [riskDistribution, setRiskDistribution] = useState(null);
  const [accuracy, setAccuracy] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    fetchPredictionData();
  }, []);

  const fetchPredictionData = async () => {
    try {
      setLoading(true);
      const [predictionsResponse, highRiskResponse, distributionResponse, accuracyResponse] = await Promise.all([
        predictionAPI.predictAll(),
        predictionAPI.getHighRisk(),
        predictionAPI.getRiskDistribution(),
        predictionAPI.getAccuracy()
      ]);
      
      setAllPredictions(predictionsResponse.data);
      setHighRiskEmployees(highRiskResponse.data);
      setRiskDistribution(distributionResponse.data);
      setAccuracy(accuracyResponse.data);
    } catch (err) {
      console.error('Failed to fetch prediction data:', err);
      setError('Failed to load prediction data');
    } finally {
      setLoading(false);
    }
  };

  const handleTrainModel = async () => {
    try {
      setLoading(true);
      await predictionAPI.trainModel();
      fetchPredictionData(); // Refresh data after training
    } catch (err) {
      console.error('Failed to train model:', err);
      setError('Failed to train model');
    } finally {
      setLoading(false);
    }
  };

  const handleEmployeePredict = async (employeeId) => {
    try {
      const response = await predictionAPI.predictEmployee(employeeId);
      setSelectedEmployee(response.data);
      setShowModal(true);
    } catch (err) {
      console.error('Failed to predict employee:', err);
      setError('Failed to predict employee');
    }
  };

  const getFilteredPredictions = () => {
    let filtered = allPredictions;

    // Apply filter
    if (filter === 'high') {
      filtered = filtered.filter(p => p.confidenceScore > 0.7);
    } else if (filter === 'medium') {
      filtered = filtered.filter(p => p.confidenceScore > 0.4 && p.confidenceScore <= 0.7);
    } else if (filter === 'low') {
      filtered = filtered.filter(p => p.confidenceScore <= 0.4);
    }

    // Apply search
    if (searchTerm) {
      filtered = filtered.filter(p => 
        p.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.employeeId.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return filtered;
  };

  const getRiskLevelColor = (riskLevel) => {
    switch (riskLevel) {
      case 'High': return 'text-red-600 bg-red-100';
      case 'Medium': return 'text-yellow-600 bg-yellow-100';
      case 'Low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getConfidenceColor = (score) => {
    if (score > 0.7) return 'text-red-600';
    if (score > 0.4) return 'text-yellow-600';
    return 'text-green-600';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-600 mb-4">{error}</div>
        <button onClick={fetchPredictionData} className="btn btn-primary">
          Retry
        </button>
      </div>
    );
  }

  const filteredPredictions = getFilteredPredictions();

  return (
    <div className="space-y-6">
      <div className="border-b border-gray-200 pb-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Attrition Prediction</h1>
            <p className="mt-2 text-gray-600">ML-powered employee attrition risk analysis</p>
          </div>
          <button
            onClick={handleTrainModel}
            className="btn btn-primary"
            disabled={loading}
          >
            <BrainIcon className="h-4 w-4 mr-2" />
            Train Model
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="stat-card">
          <div className="stat-label">Total Employees Predicted</div>
          <div className="stat-value">{allPredictions.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">High Risk Employees</div>
          <div className="stat-value text-red-600">{highRiskEmployees.length}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Model Accuracy</div>
          <div className="stat-value">{accuracy?.overallAccuracy ? `${(accuracy.overallAccuracy * 100).toFixed(1)}%` : 'N/A'}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Average Confidence</div>
          <div className="stat-value">
            {allPredictions.length > 0 
              ? `${(allPredictions.reduce((acc, p) => acc + p.confidenceScore, 0) / allPredictions.length * 100).toFixed(1)}%`
              : 'N/A'
            }
          </div>
        </div>
      </div>

      {/* Risk Distribution */}
      {riskDistribution && (
        <div className="card">
          <div className="card-header">
            <h3 className="text-lg font-medium text-gray-900">Risk Distribution</h3>
          </div>
          <div className="card-body">
            <div className="grid grid-cols-3 gap-4">
              {Object.entries(riskDistribution).map(([risk, count]) => (
                <div key={risk} className="text-center">
                  <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getRiskLevelColor(risk)}`}>
                    {risk}
                  </div>
                  <div className="mt-2 text-2xl font-bold text-gray-900">{count}</div>
                  <div className="text-sm text-gray-500">employees</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Filters and Search */}
      <div className="card">
        <div className="card-body">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <UserGroupIcon className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  className="form-input pl-10"
                  placeholder="Search employees..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <FunnelIcon className="h-5 w-5 text-gray-400" />
              <select
                className="form-input"
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
              >
                <option value="all">All Risk Levels</option>
                <option value="high">High Risk Only</option>
                <option value="medium">Medium Risk Only</option>
                <option value="low">Low Risk Only</option>
              </select>
            </div>
          </div>

          <div className="mt-4 text-sm text-gray-500">
            Showing {filteredPredictions.length} of {allPredictions.length} employees
          </div>
        </div>
      </div>

      {/* High Risk Employees Alert */}
      {highRiskEmployees.length > 0 && (
        <div className="rounded-md bg-red-50 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <ExclamationTriangleIcon className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">
                High Risk Employees Alert
              </h3>
              <div className="mt-2 text-sm text-red-700">
                {highRiskEmployees.length} employees are at high risk of attrition. 
                Consider implementing retention strategies for these employees.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Predictions Table */}
      <div className="table-container">
        <table className="table">
          <thead className="table-header">
            <tr>
              <th className="table-header-cell">Employee</th>
              <th className="table-header-cell">Risk Level</th>
              <th className="table-header-cell">Confidence</th>
              <th className="table-header-cell">Risk Factors</th>
              <th className="table-header-cell">Actions</th>
            </tr>
          </thead>
          <tbody className="table-body">
            {filteredPredictions.length > 0 ? (
              filteredPredictions.map((prediction) => (
                <tr key={prediction.employeeId} className="table-row">
                  <td className="table-cell">
                    <div>
                      <div className="font-medium text-gray-900">{prediction.employeeName}</div>
                      <div className="text-gray-500">{prediction.employeeId}</div>
                    </div>
                  </td>
                  <td className="table-cell">
                    <span className={`badge ${getRiskLevelColor(prediction.riskLevel)}`}>
                      {prediction.riskLevel}
                    </span>
                  </td>
                  <td className="table-cell">
                    <div className={`font-medium ${getConfidenceColor(prediction.confidenceScore)}`}>
                      {(prediction.confidenceScore * 100).toFixed(1)}%
                    </div>
                  </td>
                  <td className="table-cell">
                    <div className="text-sm text-gray-500 max-w-xs truncate">
                      {prediction.factors}
                    </div>
                  </td>
                  <td className="table-cell">
                    <button
                      onClick={() => handleEmployeePredict(prediction.employeeId)}
                      className="text-primary-600 hover:text-primary-900"
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="px-6 py-12 text-center text-gray-500">
                  <BrainIcon className="mx-auto h-12 w-12 text-gray-400" />
                  <div className="mt-2">No predictions found</div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Prediction Details Modal */}
      {showModal && selectedEmployee && (
        <div className="modal-overlay">
          <div className="modal-container">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-gray-900">
                Prediction Details
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500">Employee</span>
                <span className="text-sm font-bold text-gray-900">{selectedEmployee.employeeName}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500">Will Leave</span>
                <span className={`badge ${selectedEmployee.willLeave ? 'badge-danger' : 'badge-success'}`}>
                  {selectedEmployee.willLeave ? 'Yes' : 'No'}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500">Confidence</span>
                <span className={`font-medium ${getConfidenceColor(selectedEmployee.confidenceScore)}`}>
                  {(selectedEmployee.confidenceScore * 100).toFixed(1)}%
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-500">Risk Level</span>
                <span className={`badge ${getRiskLevelColor(selectedEmployee.riskLevel)}`}>
                  {selectedEmployee.riskLevel}
                </span>
              </div>

              <div>
                <span className="text-sm font-medium text-gray-500">Risk Factors</span>
                <div className="mt-1 text-sm text-gray-700">
                  {selectedEmployee.factors}
                </div>
              </div>

              <div>
                <span className="text-sm font-medium text-gray-500">Recommendations</span>
                <div className="mt-1 text-sm text-gray-700">
                  {selectedEmployee.recommendations}
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowModal(false)}
                className="btn btn-primary"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PredictionPage;
