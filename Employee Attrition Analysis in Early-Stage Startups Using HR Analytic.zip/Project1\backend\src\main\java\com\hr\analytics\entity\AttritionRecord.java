package com.hr.analytics.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;

/**
 * AttritionRecord entity for tracking attrition history
 * Stores historical data for attrition analysis and trends
 */
@Entity
@Table(name = "attrition_records")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttritionRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(name = "attrition_date", nullable = false)
    private LocalDate attritionDate;

    @Column(name = "attrition_reason")
    private String attritionReason;

    @Column(name = "final_salary")
    private Double finalSalary;

    @Column(name = "exit_interview_notes")
    private String exitInterviewNotes;

    @Column(name = "replacement_hired")
    private Boolean replacementHired = false;

    @Column(name = "replacement_date")
    private LocalDate replacementDate;

    @Column(name = "created_at", nullable = false)
    private LocalDate createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDate.now();
    }
}
