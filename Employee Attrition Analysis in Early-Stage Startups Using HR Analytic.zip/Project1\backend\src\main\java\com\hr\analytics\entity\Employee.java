package com.hr.analytics.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDate;

/**
 * Employee entity representing employee information
 * Contains all employee-related fields for attrition analysis
 */
@Entity
@Table(name = "employees")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String employeeId;

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

    @Column(nullable = false)
    private String gender;

    @Column(nullable = false)
    private Integer age;

    @Column(unique = true, nullable = false)
    private String email;

    private String phone;

    @Column(nullable = false)
    private String department;

    @Column(nullable = false)
    private String jobRole;

    @Column(nullable = false)
    private Double salary;

    @Column(name = "years_at_company", nullable = false)
    private Integer yearsAtCompany;

    @Column(name = "overtime", nullable = false)
    private Boolean overtime;

    @Column(name = "work_life_balance", nullable = false)
    private Integer workLifeBalance;

    @Column(name = "distance_from_home", nullable = false)
    private Integer distanceFromHome;

    @Column(name = "performance_rating", nullable = false)
    private Integer performanceRating;

    @Column(name = "attrition_status", nullable = false)
    private Boolean attritionStatus;

    @Column(name = "joining_date", nullable = false)
    private LocalDate joiningDate;

    @PrePersist
    protected void onCreate() {
        if (joiningDate == null) {
            joiningDate = LocalDate.now();
        }
    }
}
