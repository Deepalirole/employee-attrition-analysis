package com.hr.analytics.controller;

import com.hr.analytics.service.EmployeeService;
import com.hr.analytics.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * REST Controller for Reports operations
 * Handles CSV export and report generation
 */
@RestController
@RequestMapping("/reports")
@RequiredArgsConstructor
@Slf4j
public class ReportsController {

    private final EmployeeService employeeService;
    private final AnalyticsService analyticsService;

    /**
     * Export all employees to CSV
     */
    @GetMapping("/employees/csv")
    public ResponseEntity<byte[]> exportEmployeesToCSV() {
        log.info("Exporting employees to CSV");
        
        try {
            List<com.hr.analytics.dto.EmployeeDTO> employees = employeeService.getAllEmployees();
            byte[] csvData = generateEmployeeCSV(employees);
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment", "employees_" + 
                java.time.LocalDate.now().format(DateTimeFormatter.ISO_DATE) + ".csv");
            
            return ResponseEntity.ok()
                .headers(headers)
                .body(csvData);
        } catch (Exception e) {
            log.error("Failed to export employees to CSV", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Export attrition report to CSV
     */
    @GetMapping("/attrition/csv")
    public ResponseEntity<byte[]> exportAttritionReportToCSV() {
        log.info("Exporting attrition report to CSV");
        
        try {
            List<com.hr.analytics.dto.EmployeeDTO> attritedEmployees = 
                employeeService.getEmployeesByAttritionStatus(true);
            byte[] csvData = generateAttritionCSV(attritedEmployees);
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment", "attrition_report_" + 
                java.time.LocalDate.now().format(DateTimeFormatter.ISO_DATE) + ".csv");
            
            return ResponseEntity.ok()
                .headers(headers)
                .body(csvData);
        } catch (Exception e) {
            log.error("Failed to export attrition report to CSV", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Export department-wise report to CSV
     */
    @GetMapping("/department/{department}/csv")
    public ResponseEntity<byte[]> exportDepartmentReportToCSV(@PathVariable String department) {
        log.info("Exporting department report to CSV for: {}", department);
        
        try {
            List<com.hr.analytics.dto.EmployeeDTO> departmentEmployees = 
                employeeService.getEmployeesByDepartment(department);
            byte[] csvData = generateEmployeeCSV(departmentEmployees);
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment", "department_" + 
                department.toLowerCase().replace(" ", "_") + "_" + 
                java.time.LocalDate.now().format(DateTimeFormatter.ISO_DATE) + ".csv");
            
            return ResponseEntity.ok()
                .headers(headers)
                .body(csvData);
        } catch (Exception e) {
            log.error("Failed to export department report to CSV for: {}", department, e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get analytics summary report
     */
    @GetMapping("/analytics/summary")
    public ResponseEntity<?> getAnalyticsSummaryReport() {
        log.info("Generating analytics summary report");
        
        try {
            com.hr.analytics.dto.AnalyticsDTO analytics = analyticsService.getDashboardAnalytics();
            
            Map<String, Object> report = new java.util.HashMap<>();
            report.put("reportDate", java.time.LocalDate.now().format(DateTimeFormatter.ISO_DATE));
            report.put("totalEmployees", analytics.getTotalEmployees());
            report.put("attritionCount", analytics.getAttritionCount());
            report.put("attritionPercentage", analytics.getAttritionPercentage());
            report.put("averageSalary", analytics.getAverageSalary());
            report.put("averageWorkLifeBalance", analytics.getAverageWorkLifeBalance());
            report.put("averagePerformanceRating", analytics.getAveragePerformanceRating());
            report.put("overtimeEmployees", analytics.getOvertimeEmployees());
            report.put("highRiskEmployees", analytics.getHighRiskEmployees());
            report.put("departmentWiseAttrition", analytics.getDepartmentWiseAttrition());
            report.put("genderDistribution", analytics.getGenderDistribution());
            report.put("monthlyTrends", analytics.getMonthlyTrends());
            
            return ResponseEntity.ok(report);
        } catch (Exception e) {
            log.error("Failed to generate analytics summary report", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Generate employee CSV data
     */
    private byte[] generateEmployeeCSV(List<com.hr.analytics.dto.EmployeeDTO> employees) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintWriter writer = new PrintWriter(outputStream);
        
        // CSV Header
        writer.println("Employee ID,First Name,Last Name,Gender,Age,Email,Phone,Department," +
                      "Job Role,Salary,Years at Company,Overtime,Work Life Balance," +
                      "Distance from Home,Performance Rating,Attrition Status,Joining Date");
        
        // CSV Data
        for (com.hr.analytics.dto.EmployeeDTO employee : employees) {
            writer.println(String.format("%s,%s,%s,%s,%d,%s,%s,%s,%s,%.2f,%d,%s,%d,%d,%d,%s,%s",
                escapeCSV(employee.getEmployeeId()),
                escapeCSV(employee.getFirstName()),
                escapeCSV(employee.getLastName()),
                escapeCSV(employee.getGender()),
                employee.getAge(),
                escapeCSV(employee.getEmail()),
                escapeCSV(employee.getPhone() != null ? employee.getPhone() : ""),
                escapeCSV(employee.getDepartment()),
                escapeCSV(employee.getJobRole()),
                employee.getSalary(),
                employee.getYearsAtCompany(),
                employee.getOvertime(),
                employee.getWorkLifeBalance(),
                employee.getDistanceFromHome(),
                employee.getPerformanceRating(),
                employee.getAttritionStatus(),
                employee.getJoiningDate() != null ? employee.getJoiningDate().format(DateTimeFormatter.ISO_DATE) : ""
            ));
        }
        
        writer.flush();
        writer.close();
        return outputStream.toByteArray();
    }

    /**
     * Generate attrition CSV data
     */
    private byte[] generateAttritionCSV(List<com.hr.analytics.dto.EmployeeDTO> attritedEmployees) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintWriter writer = new PrintWriter(outputStream);
        
        // CSV Header
        writer.println("Employee ID,First Name,Last Name,Department,Job Role,Salary," +
                      "Years at Company,Work Life Balance,Distance from Home," +
                      "Performance Rating,Joining Date,Attrition Date");
        
        // CSV Data
        for (com.hr.analytics.dto.EmployeeDTO employee : attritedEmployees) {
            writer.println(String.format("%s,%s,%s,%s,%s,%.2f,%d,%d,%d,%d,%s,%s",
                escapeCSV(employee.getEmployeeId()),
                escapeCSV(employee.getFirstName()),
                escapeCSV(employee.getLastName()),
                escapeCSV(employee.getDepartment()),
                escapeCSV(employee.getJobRole()),
                employee.getSalary(),
                employee.getYearsAtCompany(),
                employee.getWorkLifeBalance(),
                employee.getDistanceFromHome(),
                employee.getPerformanceRating(),
                employee.getJoiningDate() != null ? employee.getJoiningDate().format(DateTimeFormatter.ISO_DATE) : "",
                java.time.LocalDate.now().format(DateTimeFormatter.ISO_DATE) // Assuming attrition date is today
            ));
        }
        
        writer.flush();
        writer.close();
        return outputStream.toByteArray();
    }

    /**
     * Escape CSV values to handle commas and quotes
     */
    private String escapeCSV(String value) {
        if (value == null) {
            return "";
        }
        if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }

    /**
     * Get report statistics
     */
    @GetMapping("/statistics")
    public ResponseEntity<?> getReportStatistics() {
        log.info("Getting report statistics");
        
        try {
            Map<String, Object> statistics = new java.util.HashMap<>();
            
            List<com.hr.analytics.dto.EmployeeDTO> allEmployees = employeeService.getAllEmployees();
            List<com.hr.analytics.dto.EmployeeDTO> attritedEmployees = 
                employeeService.getEmployeesByAttritionStatus(true);
            
            statistics.put("totalEmployees", allEmployees.size());
            statistics.put("attritedEmployees", attritedEmployees.size());
            statistics.put("activeEmployees", allEmployees.size() - attritedEmployees.size());
            
            // Department counts
            Map<String, Long> departmentCounts = new java.util.HashMap<>();
            for (com.hr.analytics.dto.EmployeeDTO employee : allEmployees) {
                departmentCounts.put(employee.getDepartment(), 
                    departmentCounts.getOrDefault(employee.getDepartment(), 0L) + 1);
            }
            statistics.put("departmentCounts", departmentCounts);
            
            // Gender distribution
            Map<String, Long> genderCounts = new java.util.HashMap<>();
            for (com.hr.analytics.dto.EmployeeDTO employee : allEmployees) {
                genderCounts.put(employee.getGender(), 
                    genderCounts.getOrDefault(employee.getGender(), 0L) + 1);
            }
            statistics.put("genderCounts", genderCounts);
            
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            log.error("Failed to get report statistics", e);
            return ResponseEntity.internalServerError().build();
        }
    }
}
