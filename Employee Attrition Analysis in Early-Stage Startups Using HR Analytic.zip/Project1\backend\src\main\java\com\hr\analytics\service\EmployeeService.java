package com.hr.analytics.service;

import com.hr.analytics.dto.EmployeeDTO;
import com.hr.analytics.entity.Employee;
import com.hr.analytics.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service class for Employee management
 * Contains business logic for employee operations
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    /**
     * Create a new employee
     */
    public EmployeeDTO createEmployee(EmployeeDTO employeeDTO) {
        log.info("Creating new employee with ID: {}", employeeDTO.getEmployeeId());
        
        if (employeeRepository.existsByEmail(employeeDTO.getEmail())) {
            throw new RuntimeException("Email already exists");
        }
        
        if (employeeRepository.findByEmployeeId(employeeDTO.getEmployeeId()).isPresent()) {
            throw new RuntimeException("Employee ID already exists");
        }

        Employee employee = convertToEntity(employeeDTO);
        Employee savedEmployee = employeeRepository.save(employee);
        
        log.info("Employee created successfully with ID: {}", savedEmployee.getId());
        return convertToDTO(savedEmployee);
    }

    /**
     * Update an existing employee
     */
    public EmployeeDTO updateEmployee(Long id, EmployeeDTO employeeDTO) {
        log.info("Updating employee with ID: {}", id);
        
        Employee existingEmployee = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found with ID: " + id));

        // Check if email is being changed and if it already exists
        if (!existingEmployee.getEmail().equals(employeeDTO.getEmail()) &&
            employeeRepository.existsByEmail(employeeDTO.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        // Update employee fields
        existingEmployee.setFirstName(employeeDTO.getFirstName());
        existingEmployee.setLastName(employeeDTO.getLastName());
        existingEmployee.setGender(employeeDTO.getGender());
        existingEmployee.setAge(employeeDTO.getAge());
        existingEmployee.setEmail(employeeDTO.getEmail());
        existingEmployee.setPhone(employeeDTO.getPhone());
        existingEmployee.setDepartment(employeeDTO.getDepartment());
        existingEmployee.setJobRole(employeeDTO.getJobRole());
        existingEmployee.setSalary(employeeDTO.getSalary());
        existingEmployee.setYearsAtCompany(employeeDTO.getYearsAtCompany());
        existingEmployee.setOvertime(employeeDTO.getOvertime());
        existingEmployee.setWorkLifeBalance(employeeDTO.getWorkLifeBalance());
        existingEmployee.setDistanceFromHome(employeeDTO.getDistanceFromHome());
        existingEmployee.setPerformanceRating(employeeDTO.getPerformanceRating());
        existingEmployee.setAttritionStatus(employeeDTO.getAttritionStatus());

        Employee updatedEmployee = employeeRepository.save(existingEmployee);
        
        log.info("Employee updated successfully with ID: {}", updatedEmployee.getId());
        return convertToDTO(updatedEmployee);
    }

    /**
     * Get employee by ID
     */
    public EmployeeDTO getEmployeeById(Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found with ID: " + id));
        return convertToDTO(employee);
    }

    /**
     * Get employee by employee ID
     */
    public EmployeeDTO getEmployeeByEmployeeId(String employeeId) {
        Employee employee = employeeRepository.findByEmployeeId(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found with employee ID: " + employeeId));
        return convertToDTO(employee);
    }

    /**
     * Get all employees
     */
    public List<EmployeeDTO> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();
        return employees.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Delete employee by ID
     */
    public void deleteEmployee(Long id) {
        log.info("Deleting employee with ID: {}", id);
        
        if (!employeeRepository.existsById(id)) {
            throw new RuntimeException("Employee not found with ID: " + id);
        }
        
        employeeRepository.deleteById(id);
        log.info("Employee deleted successfully with ID: {}", id);
    }

    /**
     * Search employees by name
     */
    public List<EmployeeDTO> searchEmployeesByName(String name) {
        List<Employee> employees = employeeRepository.findByNameContaining(name);
        return employees.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get employees by department
     */
    public List<EmployeeDTO> getEmployeesByDepartment(String department) {
        List<Employee> employees = employeeRepository.findByDepartment(department);
        return employees.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get employees by attrition status
     */
    public List<EmployeeDTO> getEmployeesByAttritionStatus(Boolean attritionStatus) {
        List<Employee> employees = employeeRepository.findByAttritionStatus(attritionStatus);
        return employees.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get employees by age range
     */
    public List<EmployeeDTO> getEmployeesByAgeRange(Integer minAge, Integer maxAge) {
        List<Employee> employees = employeeRepository.findByAgeRange(minAge, maxAge);
        return employees.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get employees by salary range
     */
    public List<EmployeeDTO> getEmployeesBySalaryRange(Double minSalary, Double maxSalary) {
        List<Employee> employees = employeeRepository.findBySalaryRange(minSalary, maxSalary);
        return employees.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get employees by years at company range
     */
    public List<EmployeeDTO> getEmployeesByYearsAtCompanyRange(Integer minYears, Integer maxYears) {
        List<Employee> employees = employeeRepository.findByYearsAtCompanyRange(minYears, maxYears);
        return employees.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Convert Employee entity to EmployeeDTO
     */
    private EmployeeDTO convertToDTO(Employee employee) {
        EmployeeDTO dto = new EmployeeDTO();
        dto.setId(employee.getId());
        dto.setEmployeeId(employee.getEmployeeId());
        dto.setFirstName(employee.getFirstName());
        dto.setLastName(employee.getLastName());
        dto.setGender(employee.getGender());
        dto.setAge(employee.getAge());
        dto.setEmail(employee.getEmail());
        dto.setPhone(employee.getPhone());
        dto.setDepartment(employee.getDepartment());
        dto.setJobRole(employee.getJobRole());
        dto.setSalary(employee.getSalary());
        dto.setYearsAtCompany(employee.getYearsAtCompany());
        dto.setOvertime(employee.getOvertime());
        dto.setWorkLifeBalance(employee.getWorkLifeBalance());
        dto.setDistanceFromHome(employee.getDistanceFromHome());
        dto.setPerformanceRating(employee.getPerformanceRating());
        dto.setAttritionStatus(employee.getAttritionStatus());
        dto.setJoiningDate(employee.getJoiningDate());
        return dto;
    }

    /**
     * Convert EmployeeDTO to Employee entity
     */
    private Employee convertToEntity(EmployeeDTO dto) {
        Employee employee = new Employee();
        employee.setEmployeeId(dto.getEmployeeId());
        employee.setFirstName(dto.getFirstName());
        employee.setLastName(dto.getLastName());
        employee.setGender(dto.getGender());
        employee.setAge(dto.getAge());
        employee.setEmail(dto.getEmail());
        employee.setPhone(dto.getPhone());
        employee.setDepartment(dto.getDepartment());
        employee.setJobRole(dto.getJobRole());
        employee.setSalary(dto.getSalary());
        employee.setYearsAtCompany(dto.getYearsAtCompany());
        employee.setOvertime(dto.getOvertime());
        employee.setWorkLifeBalance(dto.getWorkLifeBalance());
        employee.setDistanceFromHome(dto.getDistanceFromHome());
        employee.setPerformanceRating(dto.getPerformanceRating());
        employee.setAttritionStatus(dto.getAttritionStatus());
        employee.setJoiningDate(dto.getJoiningDate());
        return employee;
    }
}
