import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { employeeAPI, departmentAPI } from '../services/api';
import { LoadingSpinner } from '../components/LoadingSpinner';

const AddEmployee = () => {
  const [formData, setFormData] = useState({
    employeeId: '',
    firstName: '',
    lastName: '',
    gender: '',
    age: '',
    email: '',
    phone: '',
    department: '',
    jobRole: '',
    salary: '',
    yearsAtCompany: '',
    overtime: false,
    workLifeBalance: '',
    distanceFromHome: '',
    performanceRating: '',
    attritionStatus: false,
    joiningDate: ''
  });

  const [departments, setDepartments] = useState([]);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [fetchingDepartments, setFetchingDepartments] = useState(true);

  const navigate = useNavigate();

  useEffect(() => {
    fetchDepartments();
    // Set default joining date to today
    setFormData(prev => ({
      ...prev,
      joiningDate: new Date().toISOString().split('T')[0]
    }));
  }, []);

  const fetchDepartments = async () => {
    try {
      const response = await departmentAPI.getActive();
      setDepartments(response.data);
    } catch (error) {
      console.error('Failed to fetch departments:', error);
    } finally {
      setFetchingDepartments(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.employeeId.trim()) newErrors.employeeId = 'Employee ID is required';
    if (!formData.firstName.trim()) newErrors.firstName = 'First name is required';
    if (!formData.lastName.trim()) newErrors.lastName = 'Last name is required';
    if (!formData.gender) newErrors.gender = 'Gender is required';
    if (!formData.age || formData.age < 18 || formData.age > 65) {
      newErrors.age = 'Age must be between 18 and 65';
    }
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    if (!formData.department) newErrors.department = 'Department is required';
    if (!formData.jobRole.trim()) newErrors.jobRole = 'Job role is required';
    if (!formData.salary || formData.salary <= 0) newErrors.salary = 'Salary must be positive';
    if (!formData.yearsAtCompany || formData.yearsAtCompany < 0) {
      newErrors.yearsAtCompany = 'Years at company cannot be negative';
    }
    if (!formData.workLifeBalance || formData.workLifeBalance < 1 || formData.workLifeBalance > 5) {
      newErrors.workLifeBalance = 'Work life balance must be between 1 and 5';
    }
    if (!formData.distanceFromHome || formData.distanceFromHome < 0) {
      newErrors.distanceFromHome = 'Distance from home cannot be negative';
    }
    if (!formData.performanceRating || formData.performanceRating < 1 || formData.performanceRating > 5) {
      newErrors.performanceRating = 'Performance rating must be between 1 and 5';
    }
    if (!formData.joiningDate) newErrors.joiningDate = 'Joining date is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const employeeData = {
        ...formData,
        age: parseInt(formData.age),
        salary: parseFloat(formData.salary),
        yearsAtCompany: parseInt(formData.yearsAtCompany),
        workLifeBalance: parseInt(formData.workLifeBalance),
        distanceFromHome: parseInt(formData.distanceFromHome),
        performanceRating: parseInt(formData.performanceRating)
      };

      await employeeAPI.create(employeeData);
      navigate('/employees');
    } catch (error) {
      console.error('Failed to create employee:', error);
      setErrors({ 
        general: error.response?.data?.error || 'Failed to create employee' 
      });
    } finally {
      setLoading(false);
    }
  };

  if (fetchingDepartments) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="border-b border-gray-200 pb-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Add Employee</h1>
            <p className="mt-2 text-gray-600">Add a new employee to the system</p>
          </div>
          <Link to="/employees" className="btn btn-outline">
            Cancel
          </Link>
        </div>
      </div>

      <div className="card">
        <form onSubmit={handleSubmit} className="space-y-6">
          {errors.general && (
            <div className="rounded-md bg-red-50 p-4">
              <div className="text-sm text-red-800">{errors.general}</div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Personal Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Personal Information</h3>
              
              <div>
                <label className="form-label">Employee ID</label>
                <input
                  type="text"
                  name="employeeId"
                  className={`form-input ${errors.employeeId ? 'border-red-300' : ''}`}
                  value={formData.employeeId}
                  onChange={handleChange}
                  placeholder="e.g., EMP001"
                />
                {errors.employeeId && <p className="form-error">{errors.employeeId}</p>}
              </div>

              <div>
                <label className="form-label">First Name</label>
                <input
                  type="text"
                  name="firstName"
                  className={`form-input ${errors.firstName ? 'border-red-300' : ''}`}
                  value={formData.firstName}
                  onChange={handleChange}
                />
                {errors.firstName && <p className="form-error">{errors.firstName}</p>}
              </div>

              <div>
                <label className="form-label">Last Name</label>
                <input
                  type="text"
                  name="lastName"
                  className={`form-input ${errors.lastName ? 'border-red-300' : ''}`}
                  value={formData.lastName}
                  onChange={handleChange}
                />
                {errors.lastName && <p className="form-error">{errors.lastName}</p>}
              </div>

              <div>
                <label className="form-label">Gender</label>
                <select
                  name="gender"
                  className={`form-input ${errors.gender ? 'border-red-300' : ''}`}
                  value={formData.gender}
                  onChange={handleChange}
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
                {errors.gender && <p className="form-error">{errors.gender}</p>}
              </div>

              <div>
                <label className="form-label">Age</label>
                <input
                  type="number"
                  name="age"
                  className={`form-input ${errors.age ? 'border-red-300' : ''}`}
                  value={formData.age}
                  onChange={handleChange}
                  min="18"
                  max="65"
                />
                {errors.age && <p className="form-error">{errors.age}</p>}
              </div>

              <div>
                <label className="form-label">Email</label>
                <input
                  type="email"
                  name="email"
                  className={`form-input ${errors.email ? 'border-red-300' : ''}`}
                  value={formData.email}
                  onChange={handleChange}
                />
                {errors.email && <p className="form-error">{errors.email}</p>}
              </div>

              <div>
                <label className="form-label">Phone</label>
                <input
                  type="tel"
                  name="phone"
                  className="form-input"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="Optional"
                />
              </div>
            </div>

            {/* Work Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Work Information</h3>
              
              <div>
                <label className="form-label">Department</label>
                <select
                  name="department"
                  className={`form-input ${errors.department ? 'border-red-300' : ''}`}
                  value={formData.department}
                  onChange={handleChange}
                >
                  <option value="">Select Department</option>
                  {departments.map(dept => (
                    <option key={dept.id} value={dept.name}>{dept.name}</option>
                  ))}
                </select>
                {errors.department && <p className="form-error">{errors.department}</p>}
              </div>

              <div>
                <label className="form-label">Job Role</label>
                <input
                  type="text"
                  name="jobRole"
                  className={`form-input ${errors.jobRole ? 'border-red-300' : ''}`}
                  value={formData.jobRole}
                  onChange={handleChange}
                  placeholder="e.g., Software Engineer"
                />
                {errors.jobRole && <p className="form-error">{errors.jobRole}</p>}
              </div>

              <div>
                <label className="form-label">Salary</label>
                <input
                  type="number"
                  name="salary"
                  className={`form-input ${errors.salary ? 'border-red-300' : ''}`}
                  value={formData.salary}
                  onChange={handleChange}
                  min="0"
                  step="0.01"
                />
                {errors.salary && <p className="form-error">{errors.salary}</p>}
              </div>

              <div>
                <label className="form-label">Years at Company</label>
                <input
                  type="number"
                  name="yearsAtCompany"
                  className={`form-input ${errors.yearsAtCompany ? 'border-red-300' : ''}`}
                  value={formData.yearsAtCompany}
                  onChange={handleChange}
                  min="0"
                />
                {errors.yearsAtCompany && <p className="form-error">{errors.yearsAtCompany}</p>}
              </div>

              <div>
                <label className="form-label">Joining Date</label>
                <input
                  type="date"
                  name="joiningDate"
                  className={`form-input ${errors.joiningDate ? 'border-red-300' : ''}`}
                  value={formData.joiningDate}
                  onChange={handleChange}
                />
                {errors.joiningDate && <p className="form-error">{errors.joiningDate}</p>}
              </div>

              <div>
                <label className="form-label">Work Life Balance (1-5)</label>
                <select
                  name="workLifeBalance"
                  className={`form-input ${errors.workLifeBalance ? 'border-red-300' : ''}`}
                  value={formData.workLifeBalance}
                  onChange={handleChange}
                >
                  <option value="">Select Rating</option>
                  <option value="1">1 - Poor</option>
                  <option value="2">2 - Fair</option>
                  <option value="3">3 - Good</option>
                  <option value="4">4 - Very Good</option>
                  <option value="5">5 - Excellent</option>
                </select>
                {errors.workLifeBalance && <p className="form-error">{errors.workLifeBalance}</p>}
              </div>

              <div>
                <label className="form-label">Performance Rating (1-5)</label>
                <select
                  name="performanceRating"
                  className={`form-input ${errors.performanceRating ? 'border-red-300' : ''}`}
                  value={formData.performanceRating}
                  onChange={handleChange}
                >
                  <option value="">Select Rating</option>
                  <option value="1">1 - Needs Improvement</option>
                  <option value="2">2 - Meets Expectations</option>
                  <option value="3">3 - Exceeds Expectations</option>
                  <option value="4">4 - Outstanding</option>
                  <option value="5">5 - Exceptional</option>
                </select>
                {errors.performanceRating && <p className="form-error">{errors.performanceRating}</p>}
              </div>

              <div>
                <label className="form-label">Distance from Home (km)</label>
                <input
                  type="number"
                  name="distanceFromHome"
                  className={`form-input ${errors.distanceFromHome ? 'border-red-300' : ''}`}
                  value={formData.distanceFromHome}
                  onChange={handleChange}
                  min="0"
                />
                {errors.distanceFromHome && <p className="form-error">{errors.distanceFromHome}</p>}
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  name="overtime"
                  id="overtime"
                  className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  checked={formData.overtime}
                  onChange={handleChange}
                />
                <label htmlFor="overtime" className="ml-2 block text-sm text-gray-900">
                  Works Overtime
                </label>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3">
            <Link to="/employees" className="btn btn-outline">
              Cancel
            </Link>
            <button
              type="submit"
              disabled={loading}
              className="btn btn-primary disabled:opacity-50"
            >
              {loading ? <LoadingSpinner size="small" /> : 'Add Employee'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddEmployee;
