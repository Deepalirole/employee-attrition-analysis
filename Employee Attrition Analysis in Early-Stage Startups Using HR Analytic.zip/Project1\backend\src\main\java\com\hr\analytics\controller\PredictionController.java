package com.hr.analytics.controller;

import com.hr.analytics.dto.PredictionDTO;
import com.hr.analytics.service.PredictionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST Controller for ML-based attrition prediction
 * Handles prediction requests and risk analysis
 */
@RestController
@RequestMapping("/prediction")
@RequiredArgsConstructor
@Slf4j
public class PredictionController {

    private final PredictionService predictionService;

    /**
     * Predict attrition for a specific employee
     */
    @GetMapping("/employee/{employeeId}")
    public ResponseEntity<PredictionDTO> predictEmployeeAttrition(@PathVariable String employeeId) {
        log.info("Predicting attrition for employee: {}", employeeId);
        
        try {
            PredictionDTO prediction = predictionService.predictEmployeeAttrition(employeeId);
            return ResponseEntity.ok(prediction);
        } catch (Exception e) {
            log.error("Failed to predict attrition for employee: {}", employeeId, e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Predict attrition for all employees
     */
    @GetMapping("/all")
    public ResponseEntity<List<PredictionDTO>> predictAllEmployeesAttrition() {
        log.info("Predicting attrition for all employees");
        
        try {
            List<PredictionDTO> predictions = predictionService.predictAllEmployeesAttrition();
            return ResponseEntity.ok(predictions);
        } catch (Exception e) {
            log.error("Failed to predict attrition for all employees", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Predict attrition for employees in a specific department
     */
    @GetMapping("/department/{department}")
    public ResponseEntity<List<PredictionDTO>> predictDepartmentAttrition(@PathVariable String department) {
        log.info("Predicting attrition for department: {}", department);
        
        try {
            List<PredictionDTO> predictions = predictionService.predictDepartmentAttrition(department);
            return ResponseEntity.ok(predictions);
        } catch (Exception e) {
            log.error("Failed to predict attrition for department: {}", department, e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get high-risk employees
     */
    @GetMapping("/high-risk")
    public ResponseEntity<List<PredictionDTO>> getHighRiskEmployees() {
        log.info("Getting high-risk employees");
        
        try {
            List<PredictionDTO> highRiskEmployees = predictionService.getHighRiskEmployees();
            return ResponseEntity.ok(highRiskEmployees);
        } catch (Exception e) {
            log.error("Failed to get high-risk employees", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get risk distribution
     */
    @GetMapping("/risk-distribution")
    public ResponseEntity<Map<String, Long>> getRiskDistribution() {
        log.info("Getting risk distribution");
        
        try {
            Map<String, Long> riskDistribution = predictionService.getRiskDistribution();
            return ResponseEntity.ok(riskDistribution);
        } catch (Exception e) {
            log.error("Failed to get risk distribution", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get prediction accuracy metrics
     */
    @GetMapping("/accuracy")
    public ResponseEntity<Map<String, Double>> getPredictionAccuracy() {
        log.info("Getting prediction accuracy metrics");
        
        try {
            Map<String, Double> accuracy = predictionService.getPredictionAccuracy();
            return ResponseEntity.ok(accuracy);
        } catch (Exception e) {
            log.error("Failed to get prediction accuracy metrics", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Train prediction model (admin only)
     */
    @PostMapping("/train")
    public ResponseEntity<?> trainModel() {
        log.info("Training prediction model");
        
        try {
            predictionService.trainModel();
            Map<String, String> response = new HashMap<>();
            response.put("message", "Model training completed successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to train prediction model", e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.internalServerError().body(errorResponse);
        }
    }

    /**
     * Get prediction summary
     */
    @GetMapping("/summary")
    public ResponseEntity<?> getPredictionSummary() {
        log.info("Getting prediction summary");
        
        try {
            List<PredictionDTO> allPredictions = predictionService.predictAllEmployeesAttrition();
            Map<String, Long> riskDistribution = predictionService.getRiskDistribution();
            
            Map<String, Object> summary = new HashMap<>();
            summary.put("totalEmployeesPredicted", allPredictions.size());
            summary.put("riskDistribution", riskDistribution);
            summary.put("highRiskCount", riskDistribution.getOrDefault("High Risk", 0L));
            summary.put("mediumRiskCount", riskDistribution.getOrDefault("Medium Risk", 0L));
            summary.put("lowRiskCount", riskDistribution.getOrDefault("Low Risk", 0L));
            
            // Calculate average confidence score
            double avgConfidence = allPredictions.stream()
                .mapToDouble(PredictionDTO::getConfidenceScore)
                .average()
                .orElse(0.0);
            summary.put("averageConfidenceScore", avgConfidence);
            
            return ResponseEntity.ok(summary);
        } catch (Exception e) {
            log.error("Failed to get prediction summary", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get risk factors analysis
     */
    @GetMapping("/risk-factors")
    public ResponseEntity<?> getRiskFactorsAnalysis() {
        log.info("Getting risk factors analysis");
        
        try {
            List<PredictionDTO> highRiskEmployees = predictionService.getHighRiskEmployees();
            
            Map<String, Long> riskFactorsCount = new HashMap<>();
            
            for (PredictionDTO prediction : highRiskEmployees) {
                String[] factors = prediction.getFactors().split(", ");
                for (String factor : factors) {
                    riskFactorsCount.put(factor, riskFactorsCount.getOrDefault(factor, 0L) + 1);
                }
            }
            
            return ResponseEntity.ok(riskFactorsCount);
        } catch (Exception e) {
            log.error("Failed to get risk factors analysis", e);
            return ResponseEntity.internalServerError().build();
        }
    }

    /**
     * Get recommendations for high-risk employees
     */
    @GetMapping("/recommendations")
    public ResponseEntity<?> getRecommendations() {
        log.info("Getting recommendations for high-risk employees");
        
        try {
            List<PredictionDTO> highRiskEmployees = predictionService.getHighRiskEmployees();
            
            Map<String, Object> recommendations = new HashMap<>();
            recommendations.put("highRiskEmployees", highRiskEmployees.size());
            
            // Common recommendations
            Map<String, Long> commonRecommendations = new HashMap<>();
            
            for (PredictionDTO prediction : highRiskEmployees) {
                String[] recs = prediction.getRecommendations().split(", ");
                for (String rec : recs) {
                    commonRecommendations.put(rec, commonRecommendations.getOrDefault(rec, 0L) + 1);
                }
            }
            
            recommendations.put("commonRecommendations", commonRecommendations);
            
            return ResponseEntity.ok(recommendations);
        } catch (Exception e) {
            log.error("Failed to get recommendations", e);
            return ResponseEntity.internalServerError().build();
        }
    }
}
