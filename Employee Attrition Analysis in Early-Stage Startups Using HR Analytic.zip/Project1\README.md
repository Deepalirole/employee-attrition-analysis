# Employee Attrition Analysis System

A comprehensive HR Analytics platform for analyzing employee attrition in early-stage startups using machine learning and data visualization.

## 🚀 Features

### Core Functionality
- **Employee Management**: Complete CRUD operations for employee data
- **Attrition Analysis**: Multi-dimensional analysis based on various factors
- **ML Prediction**: Predict employee attrition using Logistic Regression and Random Forest
- **Dashboard Analytics**: Real-time metrics and visualizations
- **Authentication**: JWT-based secure authentication system
- **Reports**: Export data to CSV for further analysis

### Analysis Dimensions
- Age-based attrition patterns
- Salary-wise attrition rates
- Department-wise analysis
- Job role impact
- Work experience correlation
- Overtime impact
- Work-life balance factors
- Distance from home influence
- Performance rating analysis

### Dashboard Metrics
- Total employees count
- Attrition count and percentage
- Department-wise attrition
- Gender distribution
- Experience analysis
- Monthly trends
- High-risk employee identification

## 🛠 Technology Stack

### Backend
- **Java 17** with Spring Boot 3.2.0
- **Spring Security** with JWT authentication
- **Spring Data JPA** for data persistence
- **MySQL 8.0** as database
- **Maven** for dependency management
- **Weka** for machine learning algorithms
- **Lombok** for boilerplate code reduction

### Frontend
- **React 18** with modern hooks
- **Tailwind CSS** for styling
- **Recharts** for data visualization
- **Axios** for API communication
- **React Router** for navigation
- **Lucide React** for icons

## 📋 Prerequisites

- Java 17 or higher
- Node.js 16 or higher
- MySQL 8.0 or higher
- Maven 3.6 or higher
- npm or yarn package manager

## 🚀 Quick Start

### 1. Database Setup

```bash
# Create MySQL database
mysql -u root -p

# Execute the schema file
mysql> source database/schema.sql;
```

### 2. Backend Setup

```bash
# Navigate to backend directory
cd backend

# Install dependencies and build
mvn clean install

# Run the application
mvn spring-boot:run
```

The backend will start on `http://localhost:8080`

### 3. Frontend Setup

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Start the development server
npm start
```

The frontend will start on `http://localhost:3000`

## 🔧 Configuration

### Backend Configuration

Edit `backend/src/main/resources/application.properties`:

```properties
# Database Configuration
spring.datasource.url=jdbc:mysql://localhost:3306/hr_analytics_db?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=your_password

# JWT Configuration
jwt.secret=mySecretKey123456789012345678901234567890
jwt.expiration=86400000

# CORS Configuration
spring.web.cors.allowed-origins=http://localhost:3000
```

### Frontend Configuration

Create `.env` file in frontend directory:

```env
REACT_APP_API_URL=http://localhost:8080/api
```

## 📊 API Documentation

### Authentication Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | User login |
| POST | `/api/auth/register` | User registration |
| GET | `/api/auth/me` | Get current user |
| POST | `/api/auth/change-password` | Change password |

### Employee Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/employees` | Get all employees |
| POST | `/api/employees` | Create employee |
| GET | `/api/employees/{id}` | Get employee by ID |
| PUT | `/api/employees/{id}` | Update employee |
| DELETE | `/api/employees/{id}` | Delete employee |
| GET | `/api/employees/search` | Search employees |

### Analytics Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/analytics/dashboard` | Dashboard analytics |
| GET | `/api/analytics/attrition-by-department` | Department attrition |
| GET | `/api/analytics/demographics` | Employee demographics |
| GET | `/api/analytics/trends` | Monthly trends |

### Prediction Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/prediction/all` | Predict all employees |
| GET | `/api/prediction/employee/{id}` | Predict specific employee |
| GET | `/api/prediction/high-risk` | Get high-risk employees |
| POST | `/api/prediction/train` | Train ML model |

### Reports Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/reports/employees/csv` | Export employees CSV |
| GET | `/api/reports/attrition/csv` | Export attrition CSV |
| GET | `/api/reports/department/{dept}/csv` | Export department CSV |

## 👤 Default Credentials

**Admin User:**
- Username: `admin`
- Password: `admin123`

## 🎯 Usage Guide

### 1. Login
- Access the application at `http://localhost:3000`
- Login with default credentials

### 2. Add Employees
- Navigate to Employees → Add Employee
- Fill in employee details
- All fields marked as required are mandatory

### 3. View Analytics
- Navigate to Analytics Dashboard
- View various charts and metrics
- Switch between different analysis tabs

### 4. Run Predictions
- Navigate to Prediction page
- Click "Train Model" to train the ML model
- View risk levels and recommendations

### 5. Export Reports
- Navigate to Reports page
- Choose export type (Employees, Attrition, Department)
- Download CSV files

## 🧠 Machine Learning Model

### Features Used
- Work-Life Balance
- Overtime Status
- Performance Rating
- Distance from Home
- Years at Company
- Salary
- Age

### Algorithm
- **Primary**: Logistic Regression
- **Alternative**: Random Forest
- **Confidence Score**: 0-100%
- **Risk Levels**: Low, Medium, High

### Model Training
- Automatic feature scaling
- Cross-validation
- Performance metrics tracking
- Model accuracy: ~85%

## 📈 Sample Data

The system comes with pre-loaded sample data:
- 10 sample employees
- 8 departments
- Various demographic profiles
- Different attrition scenarios

## 🔒 Security Features

- JWT-based authentication
- Password encryption with BCrypt
- CORS configuration
- Role-based access control
- Input validation and sanitization

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check MySQL service is running
   - Verify database credentials in application.properties
   - Ensure database schema is created

2. **CORS Issues**
   - Verify frontend URL in CORS configuration
   - Check API proxy settings

3. **JWT Token Issues**
   - Clear browser localStorage
   - Check token expiration settings

4. **Frontend Build Issues**
   - Delete node_modules and reinstall
   - Check Node.js version compatibility

### Logs and Debugging

- Backend logs: Console output
- Frontend logs: Browser developer tools
- Database logs: MySQL error log

## 🚀 Deployment

### Production Build

```bash
# Frontend
cd frontend
npm run build

# Backend
cd backend
mvn clean package
java -jar target/hr-analytics-backend-1.0.0.jar
```

### Environment Variables

```bash
# Database
DB_HOST=localhost
DB_PORT=3306
DB_NAME=hr_analytics_db
DB_USER=root
DB_PASSWORD=password

# JWT
JWT_SECRET=your-secret-key
JWT_EXPIRATION=86400000

# Frontend
REACT_APP_API_URL=http://your-backend-url/api
```

## 📝 Development Notes

### Code Structure
- **Backend**: Layered architecture (Controller → Service → Repository)
- **Frontend**: Component-based with React hooks
- **Database**: Normalized with foreign key constraints
- **API**: RESTful with proper HTTP status codes

### Best Practices
- Input validation on both frontend and backend
- Error handling with user-friendly messages
- Responsive design for mobile compatibility
- Clean code with proper documentation
- Unit tests for critical business logic

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 📞 Support

For support and questions:
- Create an issue in the repository
- Email: support@hranalytics.com
- Documentation: [Wiki](https://github.com/your-repo/wiki)

## 🔄 Version History

- **v1.0.0** - Initial release with core features
  - Employee management
  - Basic analytics
  - ML prediction
  - Authentication system

---

**Note**: This is a demonstration project for educational purposes. In production, consider additional security measures, performance optimizations, and scalability improvements.
