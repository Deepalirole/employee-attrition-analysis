package com.hr.analytics.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

/**
 * Department entity representing company departments
 * Used for department-wise analytics and categorization
 */
@Entity
@Table(name = "departments")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String name;

    private String description;

    @Column(name = "head_of_department")
    private String headOfDepartment;

    @Column(name = "employee_count")
    private Integer employeeCount = 0;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive = true;
}
