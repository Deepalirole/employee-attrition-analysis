package com.hr.analytics.controller;

import com.hr.analytics.dto.DepartmentDTO;
import com.hr.analytics.service.DepartmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST Controller for Department management operations
 * Handles CRUD operations and department-related queries
 */
@RestController
@RequestMapping("/departments")
@RequiredArgsConstructor
@Slf4j
public class DepartmentController {

    private final DepartmentService departmentService;

    /**
     * Create a new department
     */
    @PostMapping
    public ResponseEntity<DepartmentDTO> createDepartment(@Valid @RequestBody DepartmentDTO departmentDTO) {
        log.info("Creating new department: {}", departmentDTO.getName());
        
        try {
            DepartmentDTO createdDepartment = departmentService.createDepartment(departmentDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdDepartment);
        } catch (Exception e) {
            log.error("Failed to create department", e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Update an existing department
     */
    @PutMapping("/{id}")
    public ResponseEntity<DepartmentDTO> updateDepartment(@PathVariable Long id, 
                                                          @Valid @RequestBody DepartmentDTO departmentDTO) {
        log.info("Updating department with ID: {}", id);
        
        try {
            DepartmentDTO updatedDepartment = departmentService.updateDepartment(id, departmentDTO);
            return ResponseEntity.ok(updatedDepartment);
        } catch (Exception e) {
            log.error("Failed to update department with ID: {}", id, e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Get department by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<DepartmentDTO> getDepartmentById(@PathVariable Long id) {
        log.info("Fetching department with ID: {}", id);
        
        try {
            DepartmentDTO department = departmentService.getDepartmentById(id);
            return ResponseEntity.ok(department);
        } catch (Exception e) {
            log.error("Failed to fetch department with ID: {}", id, e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    /**
     * Get department by name
     */
    @GetMapping("/name/{name}")
    public ResponseEntity<DepartmentDTO> getDepartmentByName(@PathVariable String name) {
        log.info("Fetching department with name: {}", name);
        
        try {
            DepartmentDTO department = departmentService.getDepartmentByName(name);
            return ResponseEntity.ok(department);
        } catch (Exception e) {
            log.error("Failed to fetch department with name: {}", name, e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    /**
     * Get all departments
     */
    @GetMapping
    public ResponseEntity<List<DepartmentDTO>> getAllDepartments() {
        log.info("Fetching all departments");
        
        try {
            List<DepartmentDTO> departments = departmentService.getAllDepartments();
            return ResponseEntity.ok(departments);
        } catch (Exception e) {
            log.error("Failed to fetch all departments", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Get all active departments
     */
    @GetMapping("/active")
    public ResponseEntity<List<DepartmentDTO>> getActiveDepartments() {
        log.info("Fetching active departments");
        
        try {
            List<DepartmentDTO> departments = departmentService.getActiveDepartments();
            return ResponseEntity.ok(departments);
        } catch (Exception e) {
            log.error("Failed to fetch active departments", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Delete department by ID
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteDepartment(@PathVariable Long id) {
        log.info("Deleting department with ID: {}", id);
        
        try {
            departmentService.deleteDepartment(id);
            Map<String, String> response = new HashMap<>();
            response.put("message", "Department deleted successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to delete department with ID: {}", id, e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * Get department statistics
     */
    @GetMapping("/statistics/{departmentName}")
    public ResponseEntity<DepartmentDTO> getDepartmentStatistics(@PathVariable String departmentName) {
        log.info("Fetching statistics for department: {}", departmentName);
        
        try {
            DepartmentDTO statistics = departmentService.getDepartmentStatistics(departmentName);
            return ResponseEntity.ok(statistics);
        } catch (Exception e) {
            log.error("Failed to fetch statistics for department: {}", departmentName, e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    /**
     * Initialize default departments
     */
    @PostMapping("/initialize")
    public ResponseEntity<?> initializeDefaultDepartments() {
        log.info("Initializing default departments");
        
        try {
            departmentService.initializeDefaultDepartments();
            Map<String, String> response = new HashMap<>();
            response.put("message", "Default departments initialized successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to initialize default departments", e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.internalServerError().body(errorResponse);
        }
    }

    /**
     * Update department employee count
     */
    @PostMapping("/update-count/{departmentName}")
    public ResponseEntity<?> updateDepartmentEmployeeCount(@PathVariable String departmentName) {
        log.info("Updating employee count for department: {}", departmentName);
        
        try {
            departmentService.updateDepartmentEmployeeCount(departmentName);
            Map<String, String> response = new HashMap<>();
            response.put("message", "Employee count updated successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Failed to update employee count for department: {}", departmentName, e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.internalServerError().body(errorResponse);
        }
    }

    /**
     * Get department summary
     */
    @GetMapping("/summary")
    public ResponseEntity<?> getDepartmentSummary() {
        log.info("Fetching department summary");
        
        try {
            List<DepartmentDTO> allDepartments = departmentService.getAllDepartments();
            List<DepartmentDTO> activeDepartments = departmentService.getActiveDepartments();
            
            Map<String, Object> summary = new HashMap<>();
            summary.put("totalDepartments", allDepartments.size());
            summary.put("activeDepartments", activeDepartments.size());
            summary.put("inactiveDepartments", allDepartments.size() - activeDepartments.size());
            
            // Total employees across all departments
            int totalEmployees = allDepartments.stream()
                .mapToInt(DepartmentDTO::getEmployeeCount)
                .sum();
            summary.put("totalEmployees", totalEmployees);
            
            return ResponseEntity.ok(summary);
        } catch (Exception e) {
            log.error("Failed to fetch department summary", e);
            return ResponseEntity.internalServerError().build();
        }
    }
}
