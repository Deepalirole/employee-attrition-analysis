package com.hr.analytics.exception;

/**
 * Custom exception for authorization failures
 * Thrown when user doesn't have required permissions
 */
public class AuthorizationException extends RuntimeException {

    public AuthorizationException(String message) {
        super(message);
    }

    public AuthorizationException(String message, Throwable cause) {
        super(message, cause);
    }
}
